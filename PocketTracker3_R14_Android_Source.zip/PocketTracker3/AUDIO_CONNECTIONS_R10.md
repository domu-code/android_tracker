R10 retains the features described below. See R10_CONTROLS_GUIDE.md for the new sends, envelope and row-FX controls.

# USB audio connections: T-8, Koala and PocketTracker

## T-8 into the handheld

1. On the T-8, turn **AIRA LINK (A.Lnk) OFF**, exit the menu and power-cycle it.
   Roland describes its USB audio as class-compliant USB Audio Class 2.0.
2. Connect with a data-capable cable to the handheld data/OTG port. Start with a
   direct connection. A powered hub/interface may be needed for bus-powered
   equipment, but hub compatibility varies.
3. In PROJECT > AUDIO I/O select the explicitly named INPUT. If SDL omits the
   capture endpoint, try the corresponding ALSA PCM entry. A reconnects and
   refreshes the list. Try AUTO only after explicit selection.
4. Play the T-8 internal pattern and watch the input meter. The T-8 MIX IN signal
   is **not** sent through its USB audio endpoint. A MIDI name is not evidence
   that an audio capture endpoint is available or open.
5. Select Sampler or Granular and use AUDIO IN to record. A stops, saves, and
   immediately loads the take into the instrument it started from.

R8 fixes a failure/retry bug that could replace your requested device with the
previous AUTO/SYSTEM choice. It preserves requested device names across failed
opens and hotplug, retries input/output independently, and leaves error messages
visible even when the other direction connects. Capture also tries native PCM16
and PCM32 requests when a float request is rejected. The existing audio stream
converter handles device format/rate differences without changing song tempo.

An open endpoint with a moving input meter is the useful proof. The meter does
not monitor live input through the master effects; make a take to play/process
it. Record status shows the original target instrument and elapsed time.

## Koala and USB roles

A phone running Koala normally acts as a USB host for an audio interface. A
handheld in USB host mode is also a host; a plain cable between two hosts does
not establish USB audio. For analog sampling, feed the phone/interface output
into a class-compliant USB audio interface input on the handheld.

When the computer or phone is the USB host, PocketTracker can instead use
PROJECT > AUDIO I/O > USB DEVICE. The handheld firmware must expose a USB gadget
controller and audio/MIDI functions. Turn KNULLI's system USB mode OFF first.
The helper status distinguishes:

- **AUDIO OUT + MIDI**: handheld audio goes to the host; MIDI works both ways.
  The checked stock H700 source-only profile cannot receive Koala/computer audio.
- **AUDIO IN-OUT + MIDI**: a compatible UAC2/UAC1 gadget kernel provides duplex.
  Select that endpoint as PocketTracker input to record host audio.
- **MIDI only**: note/control data, no audio endpoint.

Koala input L/L+R/R follows the connected interface. Android has an additional
Stereo input option for some silent/distorted captures. Phone/OS USB support
varies. Desktop Koala has explicit audio-device settings. No tracker software
change can add a missing firmware UAC gadget direction.

Official references:
- https://static.roland.com/manuals/T-8_manual_v102/eng/28312317.html
- https://support.roland.com/hc/en-us/articles/5836996403227-T-8-Is-the-audio-input-to-the-MIX-IN-jack-sent-to-USB-OUT
- https://manual.koalasampler.com/mobile/8-settings/
- https://koalasampler.com/help/audio-interfaces/can-i-use-koala-with-an-audio-interface.html

These routes are grounded in the documented device capabilities and exercised
with simulated opens/hotplug plus real SDL conversion. No physical RG28XX/T-8/
Koala device was attached here. If it still fails, keep the exact INPUT name,
status/format text and PocketTracker launch log for diagnosis.
