# R10 build

The complete kit includes the exact source ZIP and matching GitHub workflow.
Upload PocketTracker3_R10_Source.zip intact at the repository root, and put
build-pockettracker3-r10.yml in .github/workflows/. Run that workflow.

For a native developer build, configure CMake from native/, then run the
integration scripts with the absolute build directory as their first argument.
New checks: run_r10_workflow_integration.sh and run_r10_presets_integration.sh.

Source scripts and third-party notices are included. Do not bundle the temporary
SDL link SDK in a PortMaster installer: the firmware supplies SDL2.
