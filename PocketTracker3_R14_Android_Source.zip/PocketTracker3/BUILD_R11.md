# R11 source, testing and PortMaster build

**Supplied:** `PocketTracker3_R11_Source.zip` (self-contained C++/SDL2 repository), and `build-pockettracker3-r11.yml` (GitHub Actions workflow). Source root inside the ZIP is `PocketTracker3/`.

## Build the RG28XX installer on GitHub

Upload the source ZIP **without extracting it** to the repository root, and put the matching workflow at `.github/workflows/build-pockettracker3-r11.yml`. In GitHub, open **Actions → Build PocketTracker 3 R11 - RG28XX → Run workflow**. The workflow verifies the source SHA-256 and manifest, builds and tests a Linux host binary, builds and checks the ARM64 binary in the pinned PortMaster compatibility container, and publishes `pockettracker3_r11.zip` as an Actions artifact. Download the artifact and extract its inner `pockettracker3_r11.zip`; copy the ZIP's two entries to the Ports directory on the device. Do not rename or install an R10 binary as R11.

**The current response ships source and workflow, not a precompiled PortMaster installer.** Device-specific performance and USB I/O remain unverified until the built package is exercised on the handheld.

## Native Linux developer validation

From the extracted `PocketTracker3/` root:

```sh
cmake -S native -B build/host -DCMAKE_BUILD_TYPE=Release
cmake --build build/host -j 4
bash tests/run_r11_timing_quality_integration.sh build/host
bash tests/run_r6_sequencer_integration.sh build/host
bash tests/run_r7_editors_integration.sh build/host
bash tests/run_r8_editors_integration.sh build/host
bash tests/run_r9_reactive_integration.sh build/host
python3 tests/test_packaging.py
```

The Android/desktop and ARM64 binaries need their respective platform toolchains and SDL2 dependencies; the C++ audio engine is shared.
