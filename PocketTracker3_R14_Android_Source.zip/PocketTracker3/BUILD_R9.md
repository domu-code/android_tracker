# Building PocketTracker 3 R9

Extract PocketTracker3_R9_Source.zip with its PocketTracker3/ root. All DSP,
codec and SDL link-SDK sources are included. No firmware or proprietary ROM
assets are needed. Read R9_CONTROLS_GUIDE.md for changed controls.

Host checks:

```sh
cmake -S native -B build/host -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/host -j4
bash tests/run_r9_sends_envelopes_integration.sh build/host
bash tools/ci_r8_checks.sh build/host build/regression
```

The full SDL shell uses `cmake -S shell -B build/desktop` with SDL2 development
headers installed. Use shell/Dockerfile.portmaster and shell/build-portmaster.sh
for the original GCC AArch64 build at the Ubuntu 20.04 / glibc <=2.31 floor.
The supplied GitHub workflow automates that route from the exact source ZIP.

The delivered R9 ELF was built locally with Clang/Zig targeting AArch64 glibc
2.31 and a 2.0.18 SDL link SDK. SDL remains dynamically provided by the handheld;
the SDK is not shipped. LLVM runtime licence copies accompany this local build.
The binary's actual versioned requirements, dependencies and feature/table
signatures are checked before packaging. See VALIDATION_R9.md for execution scope.

To regenerate native UI illustrations, the full manual and preset catalogue:

```sh
bash docs/manual/rebuild.sh build/host
```

The self-contained installer is already compiled; rebuilding is optional.

The Beads DSP is vendored with its MIT license. No runtime download is needed. Host checks include run_r9_reactive_integration.sh as well as run_r9_sends_envelopes_integration.sh. Effect IDs wider than a byte are covered by the table publication test.
