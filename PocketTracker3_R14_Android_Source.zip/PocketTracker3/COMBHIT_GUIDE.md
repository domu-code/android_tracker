# Combhit: envelope-driven tuning in R9

The transient envelope now modulates tuning, rather than wet amplitude. Four
related feedback resonators process the input continuously. DAMP is a low-pass
in the feedback path; FDBK controls ringing. The instrument DADSR is separate.

| Control / command | Meaning |
|---|---|
| WET / CWT | Master insert mix: 00 exact bypass, FF fully resonant |
| TUNE / CTN | Resting fundamental, about 35 Hz-3.36 kHz |
| ENV TUNE / CEN | 00=-48 semitones, 80=zero, FF=+48 semitones |
| FDBK / CFB | About 72-99.7% bounded feedback |
| THR / CTH | Hit threshold: 00=-72 dB, FF=-6 dB |
| DAMP / CDM | Feedback brightness; higher is darker |
| DECAY / CDC | Pitch-envelope return time: about 25 ms-2.825 seconds |

A positive depth starts above TUNE and falls back; a negative depth starts
below TUNE and rises. Fractional delay reads and a short sweep attack smooth
the movement. Extreme low pitches are limited by the delay buffer.

Start with TUNE 50, FDBK D2, THR 50, DAMP 3C, DECAY B4 and ENV TUNE D0.
For selective processing, use instrument or mixer COMB 90 and COMB return FF,
with master WET 00. For the original master route, load FX_Comb_Listen.ptp and
compare WET 00/C0/FF. Try ENV TUNE 30, 80 and D0 to hear the direction change.

ENV/HIT report input detection and the triggered tuning sweep. Lower THR if
quiet hits are missed. The detector uses hysteresis and transient retriggering.
Threshold rejection prevents sweep triggers, while the static comb still
processes audio. Silence generates no synthetic excitation.

CSN controls a note's comb send; CSW controls the independent wet return.
Shape controls are shared by the send and master insert. Shared commands
restore the authored settings on STOP. No direct live input-through route is
added; sample incoming audio into Sampler/Granular first.

R9 includes detector, polarity, no-amplitude-gate, bounded-output and real
tracker render tests. Physical handheld CPU and external audio checks remain.
