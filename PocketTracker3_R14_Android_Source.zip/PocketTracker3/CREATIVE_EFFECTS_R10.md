R10 update: all nine units have bypass, order shortcuts and expanded preset banks.
L/R taps navigate units; L+Up/Down reorders; R+B bypasses. SELECT help remains open.
Beads/reverb/delay have 24 recipes each; the other six units have 16 each.
The first three delay recipes keep legacy timing/feedback behaviour; newer recipes
include timing, feedback and return levels. The examples below describe starting
recipes; consult the R10 preset catalogue for the complete banks.

# R10 creative effects and input envelopes

Open **EFFECTS** from the mixer. The new **MORPH FILTER**, **DIFFOLD** and **BEADS** sections are stereo master inserts. WET 00 bypasses each. The original REVERB, DELAY, TAPE, COMB and LO-FI remain available. TAPE, COMB and LO-FI also have the independent instrument/track sends described in R10_CONTROLS_GUIDE.md.

Hold A and use LEFT/RIGHT for one value step or UP/DOWN for sixteen. A+B restores that cell's default. SELECT shows help for the cursor; SELECT again expands it. Every musical effect parameter has a phrase/table command in its named effect tab. L/R switches tabs while the command picker is open. The browser shows the active tab and scrolls its command grid without shrinking the font.

## Beads

This is the original Beads DSP from Emilie Gillet's eurorack repository, commit `f4cfa7697095a28d292bff758beb51deb49b5a86`, with its copyright and MIT license retained. It uses the stereo 48 kHz digital mode and the original granular processor, grain shapes, randomisation, feedback and internal reverb. A streaming adapter runs it at the tracker's host sample rate. The hardware codec quality modes, calibration, buffer autosave and unpatched-input wavetable oscillator are outside this port.

Select **PRESET** and use A+LEFT/RIGHT to load a starting sound. Tapping A reloads the named preset. Loading a preset enables a useful wet mix; editing a parameter then keeps that sound until another preset or command changes it.

| Preset | Character | Starting wet |
|---|---|---|
| CLASSIC CLOUD | Regular overlapping forward grains, slight time randomisation, moderate feedback | 68 |
| MICRO DELAY | Shorter grains, recent audio, a dense regular repeat | 70 |
| SHIMMER | Longer grains an octave above the input with more internal reverb | 70 |
| LONG CLOUD | Longer buffer reach and grains for a slower stereo cloud | 88 |

Values in the app and command examples are hexadecimal. Play audio for a few seconds before freezing: an empty frozen buffer cannot produce a cloud. A master insert processes the tracker's mix; the audio recording input must first be captured or routed into an audible instrument to become part of that mix.

| Beads parameter | Command | Value meaning |
|---|---|---|
| Preset | BPS | 00 Classic, 01 Micro, 02 Shimmer, 03 Long |
| Wet | BWT | 00 bypass, FF fully processed |
| Time | BDT | Recent audio to the back of the four-second buffer |
| Size | BSZ | 00-54 reverse; near 55 shortest forward grains; larger values longer; FF enters the original delay mode after its transition |
| Density | BDN | Left of centre random, right regular; near 80 sparse; B0-E0 useful for a continuous cloud |
| Pitch | BPI | 80 unison, 00 -48 semitones, FF +48 semitones |
| Shape | BSH | Original rectangular, decaying, bell and reversed grain-envelope morph |
| Feedback | BFB | 00 none; FF capped at 94% in this adapter |
| Internal reverb | BRV | 00 none, FF full internal Beads reverb |
| Freeze | BFR | 00 records, 01 holds the existing buffer |
| Time randomness | BTR | 80 zero; either side uses the original attenurandomizer behaviours |
| Size randomness | BSR | 80 zero; larger variation can change grain direction |
| Pitch randomness | BPR | 80 zero; start close to centre for gentle detuning |
| Shape randomness | BHR | 80 zero; vary the envelope separately for each grain |

Beads WET 00 skips its DSP and buffer recording. Turn it up or load a preset before filling the buffer. Freeze holds audio only within the current session; it is a saved control, not a saved audio-buffer snapshot. The processor is intentionally distinct from the GRANULAR instrument, which plays a loaded sample.

## DIFFOLD and morph filter

DIFFOLD is a new portable implementation inspired by our earlier all-pass/folding units, not a binary port of the NTS-1 unit. **SOFT DIFFUSION**, **METAL SMEAR** and **FOLDED ROOM** provide restrained starting mixes. Its stage count spans two to eight all-pass stages per stereo channel. TIME changes diffusion lengths, FDBK controls recirculation, FOLD adds reflective nonlinear harmonics and TONE controls brightness.

The morph filter follows our Loom filter idea: continuously move between low-pass, band-pass, high-pass and notch responses. CUTOFF spans approximately 25 Hz to 20 kHz, capped below Nyquist; RES adds emphasis and DRIVE saturates its input.

| Section | Commands |
|---|---|
| DIFFOLD | DFP preset, DFW wet, DFT time, DFF feedback, DFO fold, DFC tone, DFS stages |
| MORPH FILTER | FWT wet, FCU cutoff, FRE resonance, FMO morph, FDR drive |
| REVERB | REV note send; RWT return, RDC decay, RSZ size, RDM damp, RPR pre-delay, RWD width, RMO modulation, RAG algorithm, REQ input EQ |
| DELAY | DEL note send; DWT return, TIM free time, DFB feedback, DTN tone, DWB wobble, DPG ping-pong, DSR reverb feed, DSY free/sync, DEQ input EQ |
| MASTER | EQM EQ slot, MFX OTT/DUST, MOT OTT depth, MDU DUST depth, MLG limiter pre-gain |

RAG values 00-04 choose the existing five reverb algorithms. They are prepared on the control thread so a command never allocates a reverb in the audio callback. REQ and DEQ select input EQ slots 00-7F; FF bypasses. DSY 00 is free and 01 is tempo sync using the project's time subdivision; TIM sets a free delay time. MFX 00 selects OTT and 01 selects DUST. MLG maps 00-FF to 1x-4x pre-limiter gain. SAVE/LOAD buttons are file actions rather than automation parameters.

## A threshold envelope for each effect

Move to a section's **ENVELOPE** row and tap A. Each of MASTER, REVERB, DELAY, TAPE, LO-FI, COMB, MORPH FILTER, DIFFOLD and BEADS has its own settings. Enable it, choose DESTINATION and tap A for the filtered parameter list. DPAD chooses a destination, A commits it and B cancels. B returns from setup to the effect editor. A+DPAD edits values; A+B resets the selected setting.

| Setting | Meaning |
|---|---|
| Enable | OFF preserves the ordinary effect controls; ON applies this modulation |
| Threshold | 00 = -72 dBFS, FF = 0 dBFS; lower catches quiet input |
| Attack | 00 immediate, FF two seconds; a retrigger rises from the current value |
| Hold | 00 no hold, FF one second at the envelope peak |
| Decay | 00 ten milliseconds, FF five seconds back towards the resting value |
| Depth | 80 zero; below moves down, above moves up; the result stays in range |

The effect listens to its own input, before its processing. A qualified onset starts a complete attack-hold-decay sweep. Hysteresis rearms below 65% of threshold, with a 30 ms minimum retrigger interval; a steady loud tone does not keep retriggering. The meter and TRIG counter show activity. Insert and send instances detect their own feeds independently while sharing the chosen settings. The display combines their activity.

The knob's saved value is the resting value. The envelope does not overwrite it. Delay TIME modulation multiplies the resting delay length by up to four or one quarter. Other continuous destinations move through their byte range. Physical reverb SIZE rebuilds delay lines, so it uses RSZ commands and the manual control rather than an envelope destination. Dragonfly size changes are coalesced and prepared on the UI/offline thread. Freeze, algorithm selectors, presets and file actions are discrete controls and are not envelope destinations.

COMB defaults to a **TUNE** destination. Its general envelope replaces the native CEN/THR/DECAY pitch sweep while enabled, so the two sweeps are not stacked. Leaving the general envelope OFF uses the improved native bipolar tuning envelope. Neither tuning envelope gates the comb's output amplitude. DAMP remains spectral damping inside the feedback loop.

| EFN value | Effect | EDT destinations, starting at 00 |
|---|---|---|
| 00 | MASTER | Depth of the selected OTT/DUST processor |
| 01 | REVERB | Return, decay, damp, pre-delay, width, modulation |
| 02 | DELAY | Return, feedback, tone, wobble, time, reverb feed |
| 03 | TAPE | Wet, rate, depth, drive |
| 04 | LO-FI | Wet, bits, hold, dirt |
| 05 | COMB | Wet, tune, feedback, damping |
| 06 | MORPH FILTER | Wet, cutoff, resonance, morph, drive |
| 07 | DIFFOLD | Wet, time, feedback, fold, tone, stages |
| 08 | BEADS | Wet, time, size, density, pitch, shape, feedback, reverb, time/size/pitch/shape randomness |

The **FX ENVELOPE** tab contains EFN effect selector, EON enable, EDT destination, ETH threshold, EAT attack, EHD hold, EDC decay and EAM signed depth. EFN selects the effect for subsequent envelope commands, including commands on later rows. Set it explicitly when another track may also change it. Within one row the selector is applied before the other envelope controls. Shared effect changes restore the project's settings when transport stops. Continuous effect parameters also support AUS/AUF ramps; selectors and freeze do not.

Example: enter `EFN 08`, `EDT 01`, `EON 01` to enable Beads TIME modulation. On the next row use `ETH 40`, `EDC 90`, `EAM C0` for a sensitive, positive time sweep. Adjust the resting TIME on the Beads page. To sweep comb tuning instead use `EFN 05` and `EDT 01`.

The tracker now keeps effect identities wider than a byte through native tables as well as phrases. Existing project codes retain their identity. Older app releases cannot interpret the newly added commands; keep the older version of a project if it must still open there.
