# PocketTracker 3 R7: DMG and Handpan

DMG and Handpan use independent native voices in the shared sixteen-slot synth
pool. MONO/POLY and per-note gates apply. Four-note phrase lanes and the MIDI
module can play chords, subject to the engine pool and handheld CPU capacity.
OFF releases its note/lane, and KIL or transport cuts use the existing cut fade.

## DMG

Each instrument stores sixteen waves of 32 four-bit samples. SELECT+A opens the
selected wave graph. D-pad edits step/value; A+LEFT/RIGHT paints; B+LEFT/RIGHT
changes bank. L+LEFT/RIGHT rotates, L+UP inverts, L+DOWN smooths, L+A copies,
L+B pastes and L+R undoes/redoes. SELECT+A restores that bank; B returns.
Project and preset files contain all 512 cells. Wave edits update held voices.

WAVE, SCAN, WARP, FOLD, WRAP, WIDTH, BITS, SMOOTH, CUTOFF and RES retain their
instrument and FX controls. STEP is the editing cursor. DST/DVL FX provide a
sounding-note wave-cell override without rewriting the stored bank.

## Handpan

The original struck modal body is retained. EXCITER adds STRUCK (00), PLUCKED
(01), BOWED (02) and BLOWN (03). HXM selects the mode before a note starts.
HPR pressure, HSP motion, HNO excitation noise and HXT tone work in each mode.
HAT controls the bowed/blown attack. Labels follow bow/air/pick/contact context.
The original material, modal count, decay, hardness, position, coupling, body
and stereo controls remain available.

Struck/plucked notes decay naturally, retiring when quiet or after thirty
seconds. Bowed/blown voices sustain while held and are exempt from that one-shot
limit. GATE 00 enables keyboard-style sustain. OFF/MIDI release ends the force
and retains the modal release, up to three seconds; KIL makes a short cut.

AUTOMATION YES advances a Handpan table per triggered note group and applies its
FX to those notes. Its legacy fast timed-table path is not added in R7. Phrase
FX and the graphical phrase automation lane also update held excitation controls.

The new HP_ patches Hammered Steel, Wire Pluck, Rosin Bowl and Breath Vessel are
included with the 119-patch bank. Read `R7_EDITORS_HANDPAN_GUIDE.md` for the shared
piano roll, all controls, parameter meanings and editing behaviour.
