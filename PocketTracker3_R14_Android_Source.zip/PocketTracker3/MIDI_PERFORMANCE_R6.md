# PocketTracker 3 R6: MIDI sound-module mode

9 November 2026. Eight-part compiled release.

Open PROJECT > MIDI, select INPUT, then set MODE to MODULE. Press A on PARTS. Each part has ENABLE, INST, CHANNEL, LOW, HIGH, TSP, LEVEL, PAN and VOICES. All parts are saved in the project. SINGLE restores the original selected-instrument keyboard mode.

- **Layers:** enable several parts on the same channel or ALL, with overlapping note ranges.
- **Splits:** set adjacent inclusive ranges. HIGH 59 and LOW 60 split at MIDI middle C.
- **Multiple channels:** give parts different receive channels, displayed as 01-16. ALL accepts every channel. An EXTERNAL instrument sends on its own instrument output channel.
- **Expression:** velocity follows the existing VELOCITY switch. CC64 sustains released keys; pedal-up releases them. CC123 releases held keys, CC120 cuts them, and PANIC stops internal/external notes and playback.
- **Allocation:** each part uses its matching mixer track and allocates 1-4 notes. When full, the oldest note in that part is replaced. Existing engine voice caps are shared across parts; 8 parts does not guarantee 32 simultaneous voices on every engine.

Try MIDI_Layers_Demo.ptp, MIDI_Split_Demo.ptp or MIDI_Channels_Demo.ptp with transport stopped. Load other patches or samples into the selected instrument slots as usual. MIDI input does not record into phrases. Part edits release its held notes. Instrument AUTOMATION works independently in each part. Raw pitch-wheel and program-change messages go to EXTERNAL instruments; internal synth controls use existing MIDI CC mappings.


The illustrated manual covers the MIDI module on pages 57-58. Layer/split settings are project data; choose SAVE in PROJECT to keep them. Earlier experimental settings.json STACK/SPLIT setups should be configured again in PARTS and saved in a project.
