# PocketTracker 3 R7 preset tones

**119 named native patches across eleven synthesis engines.** The earlier additional presets remain; Sampler and Granular are excluded.

INSTRUMENT > PRESET LOAD > Instruments. A+START auditions the selected patch. Use GATE 00 for held notes; OFF or MIDI note-off releases them.

Preset_Tones_Audition.wav plays one patch per second. The WAV column gives its exact start time. Four new Handpan exciter patches are at 1:55 through 1:58.

| Engine | Patches | Prefix |
|---|---:|---|
| Braids | 8 | BR |
| Rings | 8 | RG |
| Plaits | 8 | PL |
| DMG | 8 | DG |
| Handpan | 12 | HP |
| Drum Lite | 8 | DL |
| LXR DSP | 8 | LX |
| Open303 | 8 | O3 |
| FM Machines | 8 | CY |
| MD Machines | 33 | MD |
| MNM Machines | 10 | MN |

## Braids

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Warm Saw | bass / lead | C3 | 0:00 | BR_Warm_Saw.pti |
| Hollow Square | bass / pulse lead | C3 | 0:01 | BR_Hollow_Square.pti |
| Detuned Stack | poly synth | C4 | 0:02 | BR_Detuned_Stack.pti |
| Vowel Lead | vocal lead | C4 | 0:03 | BR_Vowel_Lead.pti |
| Glass Bell | bell / keys | C5 | 0:04 | BR_Glass_Bell.pti |
| Nylon Pluck | plucked keys | C4 | 0:05 | BR_Nylon_Pluck.pti |
| Air Flute | soft melodic lead | C5 | 0:06 | BR_Air_Flute.pti |
| Dust Texture | pitched noise texture | C4 | 0:07 | BR_Dust_Texture.pti |

## Rings

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Bronze Keys | metal keys | C4 | 0:08 | RG_Bronze_Keys.pti |
| Sympathetic Pluck | resonant string | C4 | 0:09 | RG_Sympathetic_Pluck.pti |
| Glass String | inharmonic pluck | C4 | 0:10 | RG_Glass_String.pti |
| FM Tines | electric piano | C4 | 0:11 | RG_FM_Tines.pti |
| Quantized Harp | harp / arpeggio | C4 | 0:12 | RG_Quantized_Harp.pti |
| Reverb String | ambient string | C4 | 0:13 | RG_Reverb_String.pti |
| Low Resonator | deep mallet bass | C2 | 0:14 | RG_Low_Resonator.pti |
| Bright Chimes | high metallic arpeggio | C5 | 0:15 | RG_Bright_Chimes.pti |

## Plaits

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Soft Analog | warm synth keys | C4 | 0:16 | PL_Soft_Analog.pti |
| Glass FM | FM keys | C4 | 0:17 | PL_Glass_FM.pti |
| Scanning Keys | wavetable keys | C4 | 0:18 | PL_Scanning_Keys.pti |
| Soft Chord | one-note chords | C3 | 0:19 | PL_Soft_Chord.pti |
| Vocal Formant | talking lead | C4 | 0:20 | PL_Vocal_Formant.pti |
| Nylon String | plucked string | C4 | 0:21 | PL_Nylon_String.pti |
| Metal Mallet | modal keys | C4 | 0:22 | PL_Metal_Mallet.pti |
| Round Kick | percussion | C2 | 0:23 | PL_Round_Kick.pti |

## DMG

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Pocket Bass | chip bass | C2 | 0:24 | DG_Pocket_Bass.pti |
| Soft Triangle | rounded keys | C4 | 0:25 | DG_Soft_Triangle.pti |
| Thin Pulse | chip lead | C4 | 0:26 | DG_Thin_Pulse.pti |
| Soft Sine | clean chip keys | C5 | 0:27 | DG_Soft_Sine.pti |
| Folded Lead | bright digital lead | C4 | 0:28 | DG_Folded_Lead.pti |
| Wave Keys | wave scan keys | C4 | 0:29 | DG_Wave_Keys.pti |
| Pixel Pad | soft low-bit chord | C4 | 0:30 | DG_Pixel_Pad.pti |
| Crunch Stab | short digital bass | C3 | 0:31 | DG_Crunch_Stab.pti |

## Handpan

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Steel Pan | rounded melodic mallet | C4 | 0:32 | HP_Steel_Pan.pti |
| Soft Copper | soft sustained mallet | C4 | 0:33 | HP_Soft_Copper.pti |
| Wood Knock | woody percussion | C4 | 0:34 | HP_Wood_Knock.pti |
| Glass Bowl | bright bell | C5 | 0:35 | HP_Glass_Bowl.pti |
| Temple Bell | long resonant bell | C4 | 0:36 | HP_Temple_Bell.pti |
| Muted Metal | short metallic keys | C4 | 0:37 | HP_Muted_Metal.pti |
| Deep Gong | low resonant percussion | C2 | 0:38 | HP_Deep_Gong.pti |
| Bright Tines | electric mallet | C5 | 0:39 | HP_Bright_Tines.pti |
| Hammered Steel | struck steel with bright hard contact | A3 | 1:55 | HP_Hammered_Steel.pti |
| Wire Pluck | picked metal string and modal body | C4 | 1:56 | HP_Wire_Pluck.pti |
| Rosin Bowl | sustained bowing with rosin texture | A3 | 1:57 | HP_Rosin_Bowl.pti |
| Breath Vessel | air-driven resonator for held melodies | F4 | 1:58 | HP_Breath_Vessel.pti |

## Drum Lite

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Round Kick | drum / percussion | C2 | 0:40 | DL_Round_Kick.pti |
| Snap Snare | drum / percussion | D3 | 0:41 | DL_Snap_Snare.pti |
| Low Tom | drum / percussion | G2 | 0:42 | DL_Low_Tom.pti |
| High Tom | drum / percussion | G3 | 0:43 | DL_High_Tom.pti |
| Closed Hat | drum / percussion | F#4 | 0:44 | DL_Closed_Hat.pti |
| Open Hat | drum / percussion | F#4 | 0:45 | DL_Open_Hat.pti |
| Ride Cymbal | drum / percussion | C5 | 0:46 | DL_Ride_Cymbal.pti |
| Driven Kick | drum / percussion | C2 | 0:47 | DL_Driven_Kick.pti |

## LXR DSP

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Round Kick | drum / percussion | C2 | 0:48 | LX_Round_Kick.pti |
| Snap Snare | drum / percussion | D3 | 0:49 | LX_Snap_Snare.pti |
| Low Tom | drum / percussion | G2 | 0:50 | LX_Low_Tom.pti |
| High Tom | drum / percussion | G3 | 0:51 | LX_High_Tom.pti |
| Closed Hat | drum / percussion | F#4 | 0:52 | LX_Closed_Hat.pti |
| Open Hat | drum / percussion | F#4 | 0:53 | LX_Open_Hat.pti |
| Ride Cymbal | drum / percussion | C5 | 0:54 | LX_Ride_Cymbal.pti |
| Driven Kick | drum / percussion | C2 | 0:55 | LX_Driven_Kick.pti |

## Open303

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Classic Acid | resonant acid bass | C2 | 0:56 | O3_Classic_Acid.pti |
| Round Sub | rounded sub bass | C2 | 0:57 | O3_Round_Sub.pti |
| Square Rubber | hollow bass | C2 | 0:58 | O3_Square_Rubber.pti |
| Biting Lead | bright acid lead | C2 | 0:59 | O3_Biting_Lead.pti |
| Soft Pluck | warm short bass | C2 | 1:00 | O3_Soft_Pluck.pti |
| Liquid Slide | legato bass | C2 | 1:01 | O3_Liquid_Slide.pti |
| Resonant Hook | resonant sequence tone | C2 | 1:02 | O3_Resonant_Hook.pti |
| Overdrive Bass | driven bass | C2 | 1:03 | O3_Overdrive_Bass.pti |

## FM Machines

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Deep Kick | percussion | C2 | 1:04 | CY_Deep_Kick.pti |
| Dry Snare | percussion | D3 | 1:05 | CY_Dry_Snare.pti |
| Metal Hat | percussion | F#4 | 1:06 | CY_Metal_Hat.pti |
| Wood Perc | percussion | C4 | 1:07 | CY_Wood_Perc.pti |
| FM Keys | FM keys / harmony | C4 | 1:08 | CY_FM_Keys.pti |
| Soft Chord | FM keys / harmony | C3 | 1:09 | CY_Soft_Chord.pti |
| Glass Bell | FM keys / harmony | C5 | 1:10 | CY_Glass_Bell.pti |
| Low Gong | percussion | C2 | 1:11 | CY_Low_Gong.pti |

## MD Machines

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Round Kick | TRX-BD percussion | C4 | 1:12 | MD_Round_Kick.pti |
| Snap Snare | TRX-SD percussion | C4 | 1:13 | MD_Snap_Snare.pti |
| Analog Tom | TRX-XT percussion | C4 | 1:14 | MD_Analog_Tom.pti |
| Hand Clap | TRX-CP percussion | C4 | 1:15 | MD_Hand_Clap.pti |
| Wood Rim | TRX-RS percussion | C4 | 1:16 | MD_Wood_Rim.pti |
| Cowbell | TRX-CB percussion | C4 | 1:17 | MD_Cowbell.pti |
| Closed Hat | TRX-CH percussion | C4 | 1:18 | MD_Closed_Hat.pti |
| Open Hat | TRX-OH percussion | C4 | 1:19 | MD_Open_Hat.pti |
| Ride Cymbal | TRX-CY percussion | C4 | 1:20 | MD_Ride_Cymbal.pti |
| Maraca | TRX-MA percussion | C4 | 1:21 | MD_Maraca.pti |
| Twin Claves | TRX-CL percussion | C4 | 1:22 | MD_Twin_Claves.pti |
| Conga | TRX-XC percussion | C4 | 1:23 | MD_Conga.pti |
| Hard Kick | TRX-B2 percussion | C4 | 1:24 | MD_Hard_Kick.pti |
| FM Kick | EFM-BD percussion | C4 | 1:25 | MD_FM_Kick.pti |
| FM Snare | EFM-SD percussion | C4 | 1:26 | MD_FM_Snare.pti |
| FM Tom | EFM-XT percussion | C4 | 1:27 | MD_FM_Tom.pti |
| FM Clap | EFM-CP percussion | C4 | 1:28 | MD_FM_Clap.pti |
| FM Rim | EFM-RS percussion | C4 | 1:29 | MD_FM_Rim.pti |
| FM Cowbell | EFM-CB percussion | C4 | 1:30 | MD_FM_Cowbell.pti |
| FM Hat | EFM-HH percussion | C4 | 1:31 | MD_FM_Hat.pti |
| FM Cymbal | EFM-CY percussion | C4 | 1:32 | MD_FM_Cymbal.pti |
| Membrane Kick | PI-BD percussion | C4 | 1:33 | MD_Membrane_Kick.pti |
| Membrane Snare | PI-SD percussion | C4 | 1:34 | MD_Membrane_Snare.pti |
| Physical Tom | PI-MT percussion | C4 | 1:35 | MD_Physical_Tom.pti |
| Metal Plate | PI-ML percussion | C4 | 1:36 | MD_Metal_Plate.pti |
| Grain Maraca | PI-MA percussion | C4 | 1:37 | MD_Grain_Maraca.pti |
| Physical Rim | PI-RS percussion | C4 | 1:38 | MD_Physical_Rim.pti |
| Physical Ride | PI-RC percussion | C4 | 1:39 | MD_Physical_Ride.pti |
| Physical Crash | PI-CC percussion | C4 | 1:40 | MD_Physical_Crash.pti |
| Physical Hat | PI-HH percussion | C4 | 1:41 | MD_Physical_Hat.pti |
| Sine Drum | GND-SN percussion | C4 | 1:42 | MD_Sine_Drum.pti |
| Noise Burst | GND-NS percussion | C4 | 1:43 | MD_Noise_Burst.pti |
| Impulse Click | GND-IM percussion | C4 | 1:44 | MD_Impulse_Click.pti |

## MNM Machines

| Tone | Use / character | Note | WAV | File |
|---|---|---|---|---|
| Warm Saw | SWAVE-SAW synth | C4 | 1:45 | MN_Warm_Saw.pti |
| Animated Pulse | SWAVE-PULSE synth | C4 | 1:46 | MN_Animated_Pulse.pti |
| Ensemble Chord | SWAVE-ENS synth | C4 | 1:47 | MN_Ensemble_Chord.pti |
| Chip Lead | SID-6581 synth | C4 | 1:48 | MN_Chip_Lead.pti |
| Static FM Keys | FM+STAT synth | C4 | 1:49 | MN_Static_FM_Keys.pti |
| Parallel FM Bell | FM+PAR synth | C4 | 1:50 | MN_Parallel_FM_Bell.pti |
| Dynamic FM Bass | FM+DYN synth | C4 | 1:51 | MN_Dynamic_FM_Bass.pti |
| Vocal Lead | VO-6 synth | C4 | 1:52 | MN_Vocal_Lead.pti |
| Pure Sine | GND-SIN synth | C4 | 1:53 | MN_Pure_Sine.pti |
| Red Noise | GND-NOIS synth | C4 | 1:54 | MN_Red_Noise.pti |

## SoundFont and external MIDI

Sounds depend on the loaded bank or external device. These zero-based General MIDI programs are suggestions, separate from the native patches:

| Tone | Decimal | Hex |
|---|---:|---|
| Acoustic Piano | 0 | 00 |
| Electric Piano | 4 | 04 |
| Jazz Organ | 16 | 10 |
| Finger Bass | 33 | 21 |
| Cello | 42 | 2A |
| String Ensemble | 48 | 30 |
| Flute | 73 | 49 |
| Soft Synth Pad | 89 | 59 |
