# R10 quick controls

| Context | Gesture | Result |
|---|---|---|
| Effects unit | L / R tap | Previous / next unit in saved order |
| Effects unit | L + Up / Down | Move current unit earlier / later |
| Effects unit | R + B | Toggle smoothed bypass |
| BYPASS cell | A | Toggle current unit |
| PRESET cell | A + Left / Right | Load previous / next recipe |
| Blank phrase/table FX cell | A | Insert last edited parameter and value |
| Four-note FX overlay | A + Left / Right | Value -/+1 |
| Four-note FX overlay | A + Up / Down | Value +16 / -16 |
| Four-note phrase | SELECT + Up | Toggle row FX overlay |
| Row FX overlay | SELECT + A | Open command browser |
| Classic FX type cell | A + Up / Down | Open command browser |
| Command browser | L / R | Previous / next expanded tab |
| MODS destination | A + Up | Open valid voice/engine destinations |
| Parameter help | SELECT | Toggle help; cursor moves keep it open |

L/R navigation happens on release so shoulder chords do not jump units first.
Hold the modifier before the other button. All three FX cells retain existing
commands. EFN or MSL requires another free cell when needed; if none is free,
the insertion is cancelled with a status message.

Files, names and settings without a sequencer command leave the previous usable
parameter remembered. EQ edits remember the edited EQ preset selector.

Input envelopes, looping DADSR, MIDI arm/record, piano group editing and USB
recovery retain the R9 controls documented in the illustrated manual.

A row containing a different EFN/MSL selector also cancels insertion, so the
new parameter cannot silently retarget that row. Use another row or clear the
conflicting selector first.
