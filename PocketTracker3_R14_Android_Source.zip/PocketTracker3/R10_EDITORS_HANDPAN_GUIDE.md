R10 retains the features described below. See R10_CONTROLS_GUIDE.md for the new sends, envelope and row-FX controls.

# PocketTracker 3 R8: editors and Handpan

## Tracker and piano roll

Open PHRASE and press SELECT+B. The piano roll edits the existing four note lanes;
it does not export, convert or maintain a second pattern. SELECT+B returns to the
previous tracker layout. SELECT+A in the tracker continues to toggle N1-N4 and FX.

| Action | Piano note controls |
|---|---|
| Move cursor | D-pad: time left/right, pitch up/down |
| Insert/select | A; a held note can be selected by its tail |
| Move note | A+LEFT/RIGHT: onset row; A+UP/DOWN: semitone |
| Length | B+LEFT/RIGHT: 12 ticks; L+LEFT/RIGHT: one tick |
| Velocity | B+UP/DOWN: one of 128 levels |
| Row instrument | L+UP/DOWN; shared by onsets on that row |
| Delete | A+B |
| Copy/paste | L+A / L+B, at cursor pitch and time |
| Undo / redo | L+R undo; B toolbox has UNDO and REDO (32 snapshots) |
| Change view | SELECT+B: tracker; SELECT+A: automation focus |
| Play/navigate | Normal START/LIVE transport and R+D-pad |

One normal phrase row is twelve ticks. Lengths are decimal ticks, velocity is
0-127. The piano roll uses one scrolling octave and sixteen time columns. Colours
identify the four lanes. A fifth overlapping note is refused. New notes choose a
free lane without stealing a tail. Notes beginning together share the row I.
N1's velocity is reflected in tracker V; other notes may override it individually.
Editing tracker V deliberately returns the row to shared velocity.

Old notes inherit GAT and instrument length. OFF or the next onset on the same
lane can shorten the displayed tail. The drawing stops at the phrase edge; it
does not claim a cross-phrase tie. Some engines have naturally decaying or gated
behaviour of their own. To hear a long bow or blown note use GATE 00 and let the
piano's explicit length or a MIDI note-off end it.

## Graphical phrase automation

SELECT+A focuses the graph. It edits real FX1, FX2 or FX3 row commands.

| Action | Automation controls |
|---|---|
| Row | D-pad LEFT/RIGHT |
| Command | A+UP: contextual FX picker |
| Slot | B+LEFT/RIGHT |
| Create point | A |
| Value | UP/DOWN by 16; A+LEFT/RIGHT by one |
| Clear | A+B |
| Interpolate | L+RIGHT between matching command endpoints |
| Undo / redo | L+R undo; B toolbox has REDO |

Interpolation writes discrete points to empty or matching cells. A different
command already occupying that slot is preserved. Graph height is normalized to
the selected command's range. A mode or model selector still uses discrete
values; interpolating it does not morph between synthesis algorithms.

## DMG 32-step, 4-bit wave editor

Select DMG. SELECT+A, or A on WAVE/STEP/VALUE, opens the graph. D-pad LEFT/RIGHT
selects a sample; UP/DOWN changes its value 0-F. A flips between 0 and F.
A+LEFT/RIGHT paints the current amplitude into the adjacent sample.

B+LEFT/RIGHT changes wave bank 00-0F. L+LEFT/RIGHT rotates the current 32 cells,
L+UP inverts, and L+DOWN smooths with a quantized neighbouring-sample filter.
L+A copies, L+B pastes, L+R undoes/redoes. SELECT+A restores the selected bank's
factory waveform. A+START auditions; B returns. Project and preset files contain
all sixteen banks; STEP is only the editing cursor.

## Handpan resonator and exciters

TYPE=HANDPAN retains its original modal body and eight existing body controls.
EXCITER adds four ways to drive it. These are lightweight, independently written
physical-inspired techniques, not a detailed simulation of any specific acoustic
instrument.

| EXCITER / HXM | Pressure / HPR | Motion / HSP | Noise / HNO | Attack / HAT |
|---|---|---|---|---|
| 00 STRUCK | Impact strength | Contact time | Impact noise | Not used |
| 01 PLUCKED | Pick force | Pick width | Pick noise | Not used |
| 02 BOWED | Bow pressure | Bow speed | Rosin | Force rise |
| 03 BLOWN | Air pressure | Air speed | Breath | Air rise |

HXT controls excitation brightness in every mode. Most controls use 00-FF;
EXCITER uses 00-03. ATTACK is approximately 1 ms to 1.5 seconds and appears in the
FX menu only for bowed/blown modes. The instrument page changes labels with the
selected exciter. Its inactive attack field is read-only for struck/plucked.

Struck/plucked notes have a transient and a natural decay. Bowed/blown modes feed
continuous excitation while held and retain ringing body modes during release.
GATE 00 enables keyboard-style sustain. OFF, explicit piano lengths, MIDI release
or transport stops release/cut the appropriate voices. Existing polyphony limits
still apply. Handpan's modal release is up to three seconds; use KIL for a short
cut. HXM on a note takes effect before excitation; later HPR/HSP/HNO/HXT/HAT edits
update sounding voices at their scheduled processing frame.

AUTOMATION YES makes Handpan table rows advance per note group; all excitation
FX work on that path. The old fast timed-table path is not added to Handpan in
this release. Phrase automation is available regardless of that table setting.

The new HP_ presets are Hammered Steel, Wire Pluck, Rosin Bowl and Breath Vessel.
`Handpan_Exciters_Audition.wav` presents struck, plucked, bowed then blown in four
approximately 3.5-second sections, using the actual tracker audio engine.
