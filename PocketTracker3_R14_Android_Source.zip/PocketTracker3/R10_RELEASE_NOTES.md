# PocketTracker 3 R10

Effects workflow update with no additional FX engines.

- L/R taps select the previous/next unit in the saved order.
- L+Up/Down reorders the current unit. R+B toggles its smoothed bypass.
- Reverb/delay remain parallel returns, injected before later insert processors.
- The master safety limiter remains final; master bypass skips EQ and dynamics.
- A on a blank phrase/table FX cell inserts the last FX-addressable edited control.
  EFN/MSL prerequisites use an additional free slot without replacing other FX.
- SELECT help stays open while navigating and editing. SELECT closes it.
- All FX tabs are visible; the selected tab expands. L/R changes tabs.
- Modulation destinations include all implemented common controls and native
  continuous engine macros, with the same list for cycling and the popup.
- 168 named effect recipes, 369 instrument .pti presets, 42 palettes.
- 295 native tone recipes rendered and level checked; 64 source-preserving
  templates retain the currently loaded media or selected MIDI channel.

Install pockettracker3_r10.zip by extracting both top-level entries into Ports.
It installs beside R9. Back up projects before copying data to R10.
R10 stores new routing/modulation fields; keep a backup before editing older songs.

The ARM64 executable is compiled and statically verified. Software checks do not
constitute an RG28XX or physical USB device test. See VALIDATION_R10.md.
