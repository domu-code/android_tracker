# PocketTracker 3 R11 — controls and timing

## Different speeds on different SONG tracks

1. Open SONG and place different CHAIN IDs in two track columns.
2. Enter the first chain. Move to the new right-hand **SPEED** column to set an optional speed for any filled phrase slot. **[1x]** means that slot inherits its chain's rate; an unbracketed value is a local override.
3. Move right once more into the settings panel. Select **CHAIN SPEED** (the fourth row) and use the normal parameter adjustment gestures (**A + D-pad**). Values cycle between **1/16x** (sixteen times slower) and **16x** (sixteen times faster).
4. Return to a phrase-slot SPEED cell. Adjust to override only that slot; use the normal clear command to return to the chain's default. Another chain on another SONG track keeps its own clock.

Examples: Track 1 at **1x**, track 2 at **1/4x**, track 3 at **4x**. Across four bars of track 1, track 2 advances only one of its own bars, while track 3 advances sixteen. Tempo and MIDI master clock remain global; the chain rate only changes the scheduling of that chain.

## Note ties and explicit releases

Open the piano roll, select a note, then open its note edit menu. **TIE / UNTIE** turns its gate length into **TIE**, meaning that there is no automatic release after the normal note length. To release it, place **NOTE OFF** later on the same note lane. **RELEASE HERE** is a convenience command for a blank step in the current phrase; for a release in a later phrase, enter an OFF in that phrase's corresponding lane. A new note on the same lane also retriggers and ends the previous note.

A tie is different from simply raising LEN. It is deliberately unlimited, even if the chain is playing at **1/16x**. Stop releases held notes. All instruments still follow their own internal envelopes where applicable, so a physically decaying sound may fade without an incoming NOTE OFF.

## Bar-relative note notation

A standard phrase is **16 rows = 1/1 bar**. Its row is **1/16**; 2 rows is **1/8**; 4 rows is **1/4**; 8 rows is **1/2**. Non-power-of-two note lengths appear as exact reduced fractions, such as **3/16**. This describes musical bar length, not an independent number of milliseconds. Changing a chain speed makes that bar longer or shorter in real time. Groove RATE rows also use exact fractions of a bar (and the RES field chooses their editing resolution). Internally stored subdivision values remain backward-compatible.

## Five quality modes

In SETUP, select **AUDIO QUALITY**:

| Mode | Sound / processing | Sampler / synth max | Rings max | Other changes |
|---|---|---:|---:|---|
| **8BIT** | Minimal CPU, gritty and reduced-rate output | 4 / 4 | 1 | 8-bit output, 4× hold; expensive effects off |
| **LOFI** | Lo-fi, modest echo | 6 / 6 | 1 | 10-bit output, 2× hold; reverb and character returns off |
| **ECO** | Mostly clean with fewer voices | 10 / 10 | 2 | 14-bit output; comb and several inserts off |
| **NORMAL** | Original R10 ceilings | 16 / 16 | 4 | Full effects, 16-bit output |
| **FULL** | Expanded polyphony for capable CPUs | 16 / 16 | 8 | Up to 10 LXR and 12 FM/Machines voices, full effects |

Mode is saved in device settings. Lower quality mainly benefits patches using costly synthesis and effects. FULL can increase CPU use sharply, especially with overlapping Rings and long release tails. If playback crackles, step down to NORMAL, ECO or LOFI.

## MIDI mapping and mute

Open MIDI settings and enter **MIDI MAPPING**. Choose or add a controller row, adjust CC, ENABLE, CHANNEL, MIN and MAX, and choose a destination by family/scope/parameter. Use the on-screen destination picker for the full catalogue. Hold **R** on a parameter to learn an incoming controller, where supported. On the INSTRUMENT screen, **R+B** toggles that instrument's mute across all tracks. Mixer track mute and solo remain separate.
