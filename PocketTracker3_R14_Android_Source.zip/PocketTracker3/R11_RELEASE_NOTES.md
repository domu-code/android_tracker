# PocketTracker 3 R11 — 0.15.0

R11 builds on the complete R10 native C++ audio engine and PortMaster app. Existing projects default to their original timing and **NORMAL** sound quality.

## New sequencing features

- Each chain has a default playback speed: **1/16×, 1/8×, 1/4×, 1/2×, 1×, 2×, 4×, 8× or 16×**. A slow chain can run beside a normal or fast one on another SONG track, because each of the eight tracks has its own scheduler cursor.
- Each of the chain's 16 phrase slots can optionally override the chain-wide rate. Clearing the SPEED cell restores inheritance, shown in brackets.
- Piano-roll note edit popup adds **TIE / UNTIE** and **RELEASE HERE**. Tied note gate **00** sustains until an explicit note-off, retrigger or transport stop. A NOTE OFF can appear in a later phrase on the same note lane.
- Musical timing, including the groove RATE grid and note lengths, is shown using fractions of a 16-row bar: **1/1, 1/2, 1/4, 1/8, 1/16** and other reduced fractions for nonstandard values. Internal song data keeps legacy timing units for compatibility.

## Five audio-quality modes

The SETUP screen's **AUDIO QUALITY** setting offers 8BIT, LOFI, ECO, NORMAL and FULL. Lower modes reduce real DSP work, cap concurrent voices, bypass heavy returns and introduce sample-hold/quantization on the output. **NORMAL** retains R10 ceilings. **FULL** permits up to eight Rings voices in place of four, along with higher limits for other physical-modelling engines. These modes are global and saved in settings.json, not inside projects.

## MIDI and performance

The MIDI mapping editor now exposes 173 destinations across track sends, mixer effects, Beads, synth controls and envelopes, with per-map channel filtering, enable, input range and current-value feedback. Controller learn and track mute/solo remain available. Instrument-wide mute is independent of track mute and is available with **R+B** from INSTRUMENT.

## Compatibility and caveats

R10 .ptp files open unchanged. New chain speed fields are omitted when left at their original defaults. Older versions may ignore the new fields; back up important songs before opening a newly saved project in an older version.

The native Linux C++ libraries and executable build and R11 engine timing integration tests pass. The actual ARM64 PortMaster release still requires the supplied GitHub Actions workflow to cross-compile and run on the target ABI. No physical RG28XX test has been performed in this environment. Performance savings depend on how many voices and effects are active in the song.
