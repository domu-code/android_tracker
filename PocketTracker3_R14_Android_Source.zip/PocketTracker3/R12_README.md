# PocketTracker 3 R12 — experimental native engine build

The separate **pockettracker3_r12.zip** is the RG28XX/PortMaster installable. Native Linux and ARM64 emulated engine tests pass. The packaged app is also launch-tested under ARM64 emulation with dummy display/audio. Physical RG28XX performance, controls and USB have not been verified. Keep R11 and your original projects backed up. R12 projects contain fields R11 does not understand.

## Build

On 64-bit Linux, install Git, CMake 3.22+, a C++20 compiler and the usual build tools. Run `bash build-r12.sh native`. The script retrieves the exact Surge revision and its pinned submodules, builds the headless library, builds PocketTracker, and runs the new integration tests. The first download is substantial. `bash build-r12.sh desktop` additionally requires SDL2 development files and makes a desktop runtime folder. Neither command creates an ARM64 package.

The Surge DSP is real upstream code, pinned to `529bb52fe6fd79777ed4ed9287aeb1b575465c61` (1.4 development snapshot). The desktop editor and plugin hosting layers are excluded. Formula modulation uses upstream's PUC Lua backend. Native engine and macros expose 774 targets. This does not recreate Surge's desktop patch browser, modulation-routing editor, wavetable browser or MSEG drawing UI. Parameter slots alone do not author those additional data structures. Factory WAV/WT/impulse resources are external assets; the desktop helper stages factory wavetables and impulses and sets `PT_SURGE_DATA`.

## Surge instrument

Select TYPE `SURGE_XT`. The initial sound is Surge's initial saw patch. There is a conservative **global limit of two simultaneously rendered Surge voices**, shared across tracks and instruments; a new hit steals the oldest of these two slots. This is a CPU/memory precaution, not a handheld benchmark. Generic instrument pan, amp envelope and sends still apply.

`SG SLOT` selects automation slot 00–0F. `SG PARAM` assigns a target from the pinned native parameter catalogue; -1/OFF leaves the slot unassigned. The path includes scene A/B and oscillator/filter/effect position, so targets remain distinguishable. `SG VALUE` edits its normalized 00–FF value; Surge converts this to its own parameter type/range. Different oscillator/effect types give their generic parameters different meanings. Some parameters are inactive until the corresponding engine/type is selected.

There are sixteen simultaneous automation/learn slots per instrument, not a limit of sixteen saved sound edits: authored values for previously assigned targets remain in the instrument's complete saved parameter state when you reuse a slot. Parameter identities are pinned to this upstream revision. Do not substitute a different Surge revision without a migration.

Use FX `SG0`–`SGF` in phrases and tables for slot 0–F. These are the ordinary three shared row FX lanes. The remembered-parameter shortcut inserts the selected slot command after an SG VALUE edit. Hold R on SG VALUE and send a CC to learn it; MIDI routing also lists SURGE 0–F. Each mapping stays on its instrument and slot. Changing the slot's assignment intentionally retargets its FX and learned controller.

Native Surge processing is in 32-frame blocks. Parameter automation may land at the next block boundary; this first integration does not promise sample-accurate type changes. Patch/file loading is not a sequencer command. Type changes and heavy configurations still need stress testing on RG28XX.

## Choke groups

Near the bottom of every **local audio** instrument page, CHOKE is OFF or 1–8. A new hit cuts older local voices in the same group across all eight tracks and supported audio engines. It also chokes older voices of the same instrument. Simultaneous group hits are processed in event order; the last wins. A short anti-click cut avoids abrupt discontinuities; this is not the voice's normal release.

OFF preserves the existing mono/poly behavior. Existing reverb/delay return tails are not erased by a choke. External MIDI instruments cannot be audio-ducked here and are outside this local audio choke implementation.

## Sidechain pumping

The new dynamics controls are together on the instrument page, below the amp envelope. Set SC SRC to a source track 1–8; OFF disables ducking. This assignment belongs to the **receiving instrument**, so it works when that instrument plays on several tracks. Many instruments can listen to the same kick track and keep different compressor settings.

- SC THR: -60 to 0 dB, the source level above which compression begins.
- SC RATIO: 1:1 to 20:1; 1:1 does not duck.
- SC ATK: 0.1–100 ms, how quickly gain falls.
- SC REL: 10–2000 ms, how quickly it recovers.
- SC DEPTH: 00 bypass to FF full reduction, applied in dB.

The detector is the source track's summed local audio, after its fader/mute and before its own sidechain attenuation. It does not include shared effect returns. A stereo-linked peak detector keeps the image stable. The detector uses the previous internal audio subblock, adding at most 256 source samples of control latency (5.33 ms at 48 kHz); dry audio is not delayed. This makes routing independent of voice processing order and prevents mutually ducking tracks from becoming an instantaneous feedback loop.

Ducking applies before the receiving instrument's output and effect-send taps. A muted source stops driving the compressor, which then releases. For a quick pumping setup: put the kick on track 1, set the bass/pad instrument's SC SRC to 1, lower SC THR until it ducks, use a fast attack and tune release to the groove. All seven dynamics controls support MIDI learn and are stored in projects and instrument presets.

## Rising-edge effect envelopes

Effect AHD envelopes and CombHit now trigger once when their level detector crosses the threshold upward. Remaining above the threshold, extra transients above threshold and downward threshold crossings do not retrigger them. A lower reset threshold re-arms the detector: 65% of trigger amplitude for effect AHD, 55% for CombHit. A new trigger requires another upward crossing. Detector timing follows its existing smoothing; it is not a raw sample zero-crossing trigger.

The sidechain compressor is deliberately continuous; it is not a threshold-retriggered AHD envelope. Keyboard/note amplitude envelopes still trigger from note events.

## Synchronized sample loops

SAMPLER and GRANULAR pages now have SYNC and BARS controls after dynamics:

- OFF: original playback.
- REPITCH: the selected loop region plays exactly once in the selected bar span; speed and pitch follow the tempo/fit together. In this strict sync mode, note pitch does not change the fitted playback speed. Use a grain mode for independent note pitch.
- GRAIN15, GRAIN45, GRAIN100: real-time overlap/add granular stretch, with 15, 45 or 100 ms windows. Scan duration stays locked to bars while note pitch sets grain playback rate. These are three window modes of one granular algorithm, not three unrelated stretch algorithms or transparent studio-quality stretching. Short modes are grainier; long modes can smear attacks.

BARS: 1/16, 1/8, 1/4, 1/2, 1, 2, 4, 8 or 16 bars. One bar is four quarter notes at the global tempo. The chosen sample/loop boundaries and reverse setting are respected. Loop phase begins with the note trigger and follows live tempo changes; it is not automatically aligned to an arrangement bar if triggered off-grid. Selecting SYNC in the instrument UI changes GATE to 0 so the loop can continue; NOTE OFF, a replacement mono note, choke or STOP ends it.

The source sample is not rewritten. The sample editor's existing offline stretch remains available separately. Synchronized playback uses the synth voice pool, so global synth voice limits apply; sample slicing and ordinary sampler-only playhead effects are not implemented in this synchronized path. Existing granular random scatter/density controls do not alter the deterministic sync stretcher. SYNC/BARS support MIDI learn; changing modes takes effect at the next note when moving between the ordinary sampler and the synchronized engine.

## Validation

`tests/run_r12_dynamics.sh` checks rising/falling/held/ripple input, hysteresis re-arm, threshold-envelope edits, CombHit, dynamics persistence, MIDI targets, cross-track choke and audio-driven ducking.

`tests/run_r12_engines.sh` checks real Surge output, all sixteen FX identities and resolved controllers, full authored-parameter persistence, MIDI writes, exact bar scan duration, and all four synchronized sample playback modes through the actual engine.

The upstream adapter smoke test exercises the parameter catalogue, banked parameter access, MIDI channel filtering, inverted ranges, invalid inputs, real audio and panic. These are host tests, not RG28XX performance/USB validation.

## Source and credits

PocketTracker keeps its existing GPL and third-party notices. Surge XT is by Claes Johanson and the Surge Synth Team, GPL-3.0-or-later; its source, notices and dependency revisions are fetched by the build helper from https://github.com/surge-synthesizer/surge . If distributing a compiled application, include the exact corresponding sources and required notices for the complete combined build, including that pinned Surge checkout and its submodules.
