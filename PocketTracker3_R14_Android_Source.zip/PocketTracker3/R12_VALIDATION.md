# R12 host validation

Validated on native x86-64 Linux. No ARM64 runtime, PortMaster package, USB or handheld performance claim.

The portable build helper was exercised against the pinned upstream checkout and completed both new integration tests. Four existing regression suites were run against the resulting libraries.

## r12-verified-build.log

```text
PASS parameters=774 rms=0.0832361 render_ms=12.6044
PASS rising crossings, sustained/ripple/falling rejection, re-arm, edit above threshold, JSON, MIDI targets, cross-track choke and source-driven ducking
PASS real Surge audio, all 16 slot FX, named catalogue, MIDI state, full parameter persistence, exact bar scan and four live sample-sync modes
```

## r11-regression.log

```text
PASS R11: bar fractions, five quality profiles, independent chain speeds, per-slot override, project persistence, tied note crossing phrase boundary
```

## r9-regression3.log

```text
PASS R9 reactive effects: official Beads stereo DSP at 44.1/48k, four audible presets, filter/diffusion, AHD retrigger and signed depth, destination UI, contextual help geometry, command tabs, all 42 new controllers, wide table atomic publication and persistence
```

## r9-sends.log

```text
PASS R9: physical A+directions and both SELECT+A orders, preserved four-note cells, mixer/instrument sends, persistence, independent looping DADSR, bipolar comb tune sweep without amplitude gating, isolated audible wet buses, return/mute/track isolation, 14 envelope engine paths and 27 FX commands
```

## fx-dispatch.log

```text
PASS: production A+UP/release dispatch, FX-only inheritance, hidden command safety, filtered selection, Plaits model exception, table and MOD destination picker
```

The R9 controller-range assertion was updated to recognize the new, distinct 512–527 Surge slot range, while retaining identity round-trip, uniqueness and non-collision checks.

## ARM64 execution

The full SDL app and headless Surge library were cross-compiled against a glibc 2.31 target sysroot. Both R12 integration suites and the 774-target Surge smoke test passed under qemu-aarch64. The app and private libraries require no glibc version newer than 2.31; SDL2 remains a device-provided library.

```text
PASS parameters=774 rms=0.0831193 render_ms=262.978
```

```text
PASS real Surge audio, all 16 slot FX, named catalogue, MIDI state, full parameter persistence, exact bar scan and four live sample-sync modes
```

```text
PASS rising crossings, sustained/ripple/falling rejection, re-arm, edit above threshold, JSON, MIDI targets, cross-track choke and source-driven ducking
```


## Packaged application launch

```text
PASS packaged ARM64 SDL launch, Surge project load and graceful SIGTERM shutdown
```

The test used the staged private libraries and factory Surge data, SDL dummy audio/video, and the included R12_Surge_Check.ptp project. The app rendered its frame loop and saved settings on shutdown. This does not verify physical controls, device audio, USB or real-time playback performance on an RG28XX.
