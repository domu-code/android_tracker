# How to build the installable R13.1 ZIP

**Required:** the original unmodified `pockettracker3_r13.zip` installer and the updated R13.1 source tree. The verified R13 original binary and its bundled Surge adapter/assets are retained as the base package; the R13.1 compiled ARM64 binary replaces the old executable.

1. Extract the `PocketTracker3_R13_1_Source.zip` into a GitHub repository root. Keep its `tools/`, `native/`, `shell/`, `build-support/`, `factory/`, and `.github/workflows/` folders together.
2. Add the original `pockettracker3_r13.zip` to the root of the repository (large file; alternatively arrange an authenticated asset download before building).
3. In GitHub Actions select **Build PocketTracker 3 R13.1 PortMaster** then **Run workflow**.
4. Download the resulting `pockettracker3_r13_1_portmaster` artifact; it contains `pockettracker3_r13_1.zip`.
5. Backup the existing `ports/pockettracker3_r13/data` directory before installing. R13.1 uses the same PortMaster launcher and data folder.

**Safety:** the packaging script rejects wrong-architecture executables, glibc greater than 2.31, an ARM64 executable identical to R13's, or corrupt ZIP output. This workflow is supplied but not yet executed in GitHub Actions; further toolchain adjustments may be required on the runner. Do not install a failed or unverified build.
