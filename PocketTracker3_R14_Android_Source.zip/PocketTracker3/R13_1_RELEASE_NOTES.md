# PocketTracker 3 R13.1 — PortMaster installer

Built upon the R13 source code and **R13 PortMaster layout**, using the same `ports/pockettracker3_r13` installation folder so existing projects do not have to be migrated.

## Changes

* **Surge XT instrument name:** the instrument type row now displays `SURGE XT`, not the erroneous default `sampler`. This fixes the display error. It does not constitute verification that all Surge engine parameters work on physical hardware; that remains an independent check.
* **Envelope trigger feedback:** the Effects Envelope detail view shows live monitored signal level (dB) and trigger count. With incoming audio playing and the envelope enabled, select `THRESHOLD` and press **A** to set the trigger 6 dB below the monitored input peak. A+arrow still manually edits values; if no detectable audio arrives, no threshold is set.
* **Envelope rising-edge detection:** a rising transient must now wait for the refractory interval to expire, as intended.
* **PHAT master rack:** select `PHAT` as a third master type beside OTT and DUST; adjust the dedicated depth byte for stereo-linked parallel compression and soft saturation. Depth 00 is exact bypass. The existing master limiter is retained downstream. PHAT is an economical stereo effect rather than an expensive multi-band oversampled processor.
* **Automatable PHAT control:** new tracker FX `MPH` (0x132; amount 00–FF), MIDI mapping `PHAT` ID 212. Existing FX IDs and mapping IDs are unchanged.
* **PHAT GLUE master preset:** appended as index 16, preserving all sixteen R13 master presets (index 0–15), including `DARK PRESS`.
* **Persistence:** project JSON saves `phatDepth` and master mode `2` as optional fields. Projects without those fields retain R13 defaults. Master MIDI mappings and older instruments remain compatible.

## Validation completed in this workspace

* x86_64 host C++ audio/UI static-library compilation: passed.
* Direct PHAT stereo DSP test: exact dry bypass at zero depth; finite, changed output when enabled.
* Song JSON and master-preset regression: older R13 default values, master preset 15, PHAT preset 16, PHAT MIDI mapping, FX automation registry: passed.

## PortMaster build — 17 November 2026

This package contains a newly compiled AArch64 R13.1 application, the existing Surge adapter, runtime libraries and factory assets. It replaces the old R13 binary. The project screen and application version are R13.1 / 0.17.1.

Built with Ubuntu focal GCC 9.3 and a glibc 2.31 cross sysroot. SDL2 remains dynamically linked to the handheld's own SDL2; the dummy-backend SDL library used for build validation is not included.

ARM64 emulation checks passed: PHAT stereo processing and exact bypass, project serialization, PHAT MIDI mapping and preset compatibility; real Surge audio, its 16 parameter-slot FX, MIDI state and sample-sync playback; application launch with dummy audio/video and clean SIGTERM shutdown. Physical RG28XX performance, USB devices and controls have not been tested here.

The missing MPH help entry was added so the FX catalogue descriptions remain aligned. The build recipe now installs a compatible CMake version and links the bundled Surge C++ runtime.

Back up ports/pockettracker3_r13/data/ first. Extract the two top-level items into your ports folder, replacing existing program files. Keep your existing data folder. The launcher remains PocketTracker 3 R13.sh to update the existing menu entry.
