# PocketTracker 3 R13 — start here

R13 combines the R12 Surge/dynamics/sample-sync build with USB-keyboard LIVE launching, MIDI LIVE commands, MIDI effect bypass and working synth ROOT transposition. Launch **PocketTracker 3 R13**; R11 does not contain the Surge or sidechain additions.

## Hear ducking immediately

Load **R13_Ducking_Demo.ptp** from Projects. Track 1 is the kick/source; track 2 is the receiving pad. Start playback. Open instrument 1 (PAD DUCKED BY T1), scroll below AMP ENV and change SC DEPTH between 00 and FF to compare.

The receiving instrument owns its ducking settings:

| Control | Purpose | Starting point |
| --- | --- | --- |
| SC SRC | Audio source track, 1–8; OFF disables | 1 for the demo kick |
| SC THR | Source threshold in dB | Around -35 to -45 dB; lower if necessary |
| SC RATIO | Compression ratio | 4:1 to 12:1 |
| SC ATK | How quickly gain drops | 0.5–3 ms |
| SC REL | Recovery time | 200–400 ms at 120 BPM |
| SC DEPTH | Reduction amount | FF to hear full ducking |

SC RATIO at 1:1, SC DEPTH at 00, an OFF source or a silent/muted source will not pump. The detector reads local source-track audio after its fader/mute, before that track's own ducking; shared effect returns are not detector inputs. External MIDI sound is not local source audio. Ducking happens before the receiving voice's sends. Control latency is up to one internal 256-frame block.

Sidechain compression follows level continuously. It is different from the effect AHD/CombHit envelopes, which fire only on rising threshold crossings and re-arm below their hysteresis threshold.

## Find Surge XT

Load **R13_Surge_Start_Here.ptp**, or edit an instrument's TYPE to **SURGE_XT**. Start with SG SLOT 00. SG PARAM chooses one of the 774 named native targets; SG VALUE edits it from 00–FF. SG0–SGF in phrases/tables automate the sixteen assigned slots. Hold R while selecting SG VALUE and send a MIDI CC to learn that instrument/slot, or select SURGE 0–F in MIDI routing. Edited parameter values remain saved when a slot is reused for another target.

Different oscillator/filter/effect types change which controls are meaningful. Assign the corresponding type first. The global two-voice cap is shared across all Surge instruments. This contains real pinned Surge DSP, not its desktop plugin editor: the patch browser, graphical MSEG editor, modulation-routing editor and wavetable browser are not reproduced. Those editing data structures are not created merely by selecting parameter IDs. Factory wavetable/impulse assets remain included from R12. Rapid type changes and complex Surge settings need handheld performance testing.

## USB computer keyboard: looping LIVE scenes

Connect a USB keyboard. On the main tracker, **F8** arms LIVE keys and selects SONG. Text/picker/confirmation overlays disarm it; **F8** or **Esc** disarms it without stopping the music.

| Keys | Song rows within the bank |
| --- | --- |
| 1 2 3 4 5 6 7 8 | 0–7 |
| Q W E R T Y U I | 8–15 |
| A S D F G H J K | 16–23 |
| Z X C V B N M comma | 24–31 |

An unmodified key launches that song row across tracks. Hold **Shift** to launch only the selected SONG track. **F6/F7** change the 32-row bank; eight banks cover rows 0–255. The status line shows the selected row/bank. Assign your chains to SONG rows first. Empty row cells stop/silence their respective tracks. The chain loops until another launch or stop, using the existing LIVE scheduler. A new launch is queued at the chain boundary. **Space** stops all tracks. Ordinary keyboard editing remains available when LIVE keys are off. Gamepad editing remains available while keyboard launches are armed.

## MIDI LIVE launches and bypass

In MIDI routing select MIX → LIVE ROW for scene launches, TRK → LIVE CELL for one selected scope track, or TRK → LIVE STOP to stop that scope track. Assign the controller/channel as usual. LIVE STOP responds when its mapped output is 1. LIVE launches automatically enable LIVE mode.

For exact row addressing use output range 0–127 for the first 128 rows, or 128–255 for the second 128. Sending CC value 0 then selects the range's first row, and 127 selects its last. A full 0–255 range necessarily skips alternate rows because one CC has 128 values.

MIX also lists BYP MASTER, BYP REVERB, BYP DELAY, BYP TAPE, BYP LOFI, BYP COMB, BYP FILTER, BYP DIFFOLD and BYP BEADS. Map 0–1: 0 enables the unit, 1 bypasses it. TRACK MUTE and instrument MUTE remain independent existing destinations.

## ROOT

ROOT now transposes the sample-free synth engines: C4 is neutral, C5 is one octave up, C3 is one octave down. Changing it updates future synth notes and held frequency-driven synth voices at the next block. The handpan fixes its resonator tuning at the strike, so its new ROOT applies on the next trigger. Hold R at ROOT and send a CC, or use INS → ROOT NOTE in MIDI routing. Existing synth presets with a non-C4 ROOT now hear that setting. Sampler/granular/SoundFont root remains sample-pitch calibration with its established direction; synced REPITCH fixes loop duration, so use grain modes for independent note pitch. ROOT audition plays the chosen root once rather than doubling the transpose.

## Effects, looping and saved work

Effect unit L/R navigation follows the chosen effect order. L+Up/Down moves a unit; R+B bypasses it. Sampler/Granular SYNC offers REPITCH and GRAIN15/45/100; BARS sets the loop duration from 1/16 to 16 bars. The three grain lengths are window variants of one overlap/add stretcher, not three separate studio algorithms. SYNC mode changes between ordinary and synced engines take effect on the next note.

R13 uses a separate ports folder. Copy projects/presets/samples from the older data folder while both applications are closed. Keep originals: R11 does not understand R12/R13 fields and mapping destinations. Physical RG28XX USB, controls and real-time load still require device testing.
