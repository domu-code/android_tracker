# Recent PocketTracker request audit

Reviewed the current R12 source/installer against the recent PocketTracker conversations available to this session, then added the specific gaps below. Historical assistant statements were checked against source rather than treated as implementation evidence.

| Request | R13 status and implementation |
| --- | --- |
| Surge XT engine and relevant FX/MIDI control | Retained real R12 Surge adapter, pinned upstream 529bb52fe6fd79777ed4ed9287aeb1b575465c61, 774 parameter targets through 16 assignable slots; full saved state. Desktop editors and two-voice limit remain explicit. |
| Eight instrument choke groups | Retained R12 OFF/1–8; cross-track local audio, including same-instrument hits. |
| Configurable source-driven ducking | Retained R12 receiving-instrument SC SRC/THR/RATIO/ATK/REL/DEPTH with MIDI learn and persistence. Added ready-to-hear demo and control guide. |
| Trigger effect envelopes only on rising threshold crossings | Retained R12 hysteretic AHD/CombHit detector; held/falling levels do not retrigger. |
| LGPT-like sampler looping and tempo fit | Existing sample loop modes plus R12 REPITCH and granular window modes, bar fractions, reverse/boundaries. Limits in quick start. |
| Effects order, bypass and L/R unit navigation | Existing order editing and shortcuts verified. Added nine independent MIDI bypass destinations. |
| MIDI routing, track mute and instrument mute | Existing map editor, enable/range/channel feedback, track and instrument mute retained. Root/bypass/LIVE destinations appended without renumbering saved IDs. Not every UI/file operation is a continuous MIDI parameter. |
| ROOT alters synth pitch | Fixed sample-free synth derivation and live held-note offset; preserved sampler/SoundFont calibration and audition. Added ROOT learn target. Existing non-neutral ROOT settings become audible. |
| USB QWERTY keyboard launches looping chains | Added production SDL event handler: F8 arm, 32 keys × 8 song-row banks, whole row/Shift selected track, Space stop, overlay isolation. Uses existing LIVE loop scheduler. |
| MIDI launches replace looping chains | Added LIVE ROW/CELL/STOP mapping destinations with track scope and channel/range filtering. |
| Chain-local speed, phrase overrides, note ties, timing fractions, quality profiles | Retained R11 implementation. |
| Four-note phrases plus row FX, MIDI recording and piano-roll editing | Retained R10/R11 implementation; unchanged limits. |
| Engine parameter modulation, 12 modulation slots, remembered FX, contextual help | Existing R12 code has SYNTH_PARAMETER routes, model-aware destination picker, twelve slots and parameter FX. Retained. |
| USB audio/MIDI, sampler take auto-load, loop editing, effects sends | Retained existing audio/session engine. Physical-device compatibility is not inferred from emulation. |
| Separate MIDI-only sound module and VJ visualizer project | Kept as its separate instrument project; the tracker/sequencer is preserved here. |

The audit is limited to retrieved recent requests and current source; it does not assert an exhaustive search of every past conversation or that every desktop Surge feature is implemented.
