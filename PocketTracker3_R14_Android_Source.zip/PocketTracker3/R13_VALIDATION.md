# R13 build validation — 16 November 2026

New cumulative AArch64 application compiled with GCC 10.2.1 against glibc 2.31. The unchanged real Surge adapter and its private runtime/assets are retained byte-for-byte from the R12 installer. The application requires glibc 2.29 and dynamically uses device SDL >=2.0.18.

Executed under qemu-aarch64 against the target sysroot:

- R13 completion: every sample-free synth's ROOT octave/audition derivation; held voice pitch change including the non-stable pitch branch; unique MIDI destination IDs; independent nine-unit bypass; ROOT project round-trip; production SDL LIVE-key handler and real host launching, banks, stop, arrow-release and text-overlay isolation; mapped MIDI scene launch/track stop.
- R12 dynamics: rising/held/ripple/falling and re-arm tests, CombHit, dynamics persistence/MIDI targets, cross-track choke and audio-driven ducking.
- R12 engines: real Surge audio, all sixteen FX slots, catalogue, MIDI state, full authored parameter persistence, exact bar scan duration and all four synchronized sample playback modes.
- R11 timing/quality: independent chain rates, per-phrase override, ties across phrase boundaries, bar fractions, five quality profiles and legacy defaults.
- R6 sequencer: four-note lanes, releases, transpose lanes, automation and repeated LIVE stop/relaunch.
- R13 demo: actual packaged kick and pad instruments, pad-only render with ducking enabled/disabled. Dry energy 327.299; ducked energy 3.46748 (0.0105942 ratio). Both outputs are finite and nonzero; the reduction is source-driven compression, not a mute.

The production app is also boot-tested with the packaged shared libraries, Surge data and dummy SDL audio/video. Final ZIP checks verify actual ARM64, glibc requirements, pinned adapter checksum, executable permissions, isolated launcher/folder, no bundled SDL and archive integrity.

No physical RG28XX controls, USB devices, CPU benchmark or real-time latency test was performed. The recent-request audit is explicit about the remaining Surge desktop-editor limitations and separate MIDI-only/VJ project.
