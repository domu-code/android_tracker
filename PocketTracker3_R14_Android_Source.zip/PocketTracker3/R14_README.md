# PocketTracker 3 R14

PortMaster / AArch64 update for the RG28XX. Application version 0.18.0.

## Install

Back up `ports/pockettracker3_r13/data` first. Extract the ZIP into your existing `ports` directory and replace program files. Keep your existing `data` folder. The launcher copies any missing factory files on the first R14 start. The two top-level items retain their existing names (`PocketTracker 3 R13.sh` and `pockettracker3_r13`) so this updates the existing menu entry and reuses your projects. The PROJECT screen now says **PT3 R14**.

Surge has been removed from the engine, type picker, FX picker, MIDI destinations, build dependencies and this package. An old Surge instrument imports as a muted, empty sampler; its other tracks remain intact. Existing Surge files left by extracting over an older installation are unused and can be deleted: `surge-data` and `libs.aarch64/libpockettracker-surge-adapter.so`.

## Effects without notes

An empty note row addresses the last instrument played on that track. Volume, pitch, pan, filters, sends, applicable engine parameters, sample seeking, slice selection and table switching can change a sustained voice. A command cannot revive a one-shot that has already finished. Note delay, velocity, voice allocation and a slide requiring a new target note still need a note trigger.

Original commands remain alongside the LGPT commands. The old `OFF` command is removed from the picker. Saved OFF cells import as absolute `PLOF` cells: old OFF 80 becomes PLOF 8000, in phrases and tables.

## LGPT values and controls

The **LGPT (4 HEX DIGITS)** section contains all 27 commands. LGPT cells retain four hexadecimal digits in the phrase editor, table editor, playback events and saved files. A+LEFT/RIGHT changes the low byte by one; A+UP/DOWN changes the high byte by one. Ordinary commands retain their original two-digit values. The compact FX font keeps all three columns visible.

For `aabb`, `aa` and `bb` are separate bytes. Signed bytes use two's complement: FF = -1, F4 = -12, 0C = +12. Audio operations use PocketTracker's engines and native DSP; this is command support, not an LGPT project-file importer or a bit-identical LGPT audio renderer.

| Command | Hex syntax and action |
|---|---|
| ARPG | Four semitone nibbles after the root; 4700 makes root/+4/+7. 0000 clears. |
| CRSH | aabb: drive aa and crush low nibble of bb; a zero section keeps its current value. |
| DLAY | 00bb: delay this row's note by bb ticks. |
| FBMX | aabb: ramp feedback mix to bb; aa=00 immediate, higher aa slower. |
| FBTN | aabb: ramp feedback tuning to bb. |
| FCUT | aabb: ramp cutoff to bb; FF open. |
| FLTR | aabb: cutoff aa and resonance bb immediately; FF00 open/no resonance. |
| FRES | aabb: ramp resonance to bb. |
| GROV | aabb: select groove bb; aa=00 this track, nonzero all tracks. Phrase command. |
| HOP | Phrase: jump to row bb in the next phrase; bb=FF stops the track. This row's note/other commands run. Table: aa repetitions to row b, aa=00 infinite. |
| IRTG | 00bb: retrigger the sample instrument with cumulative signed pitch bb, retaining table position. |
| KILL | 00bb: cut the voice after bb ticks; 0000 immediate. |
| LEGA | aabb: exponential pitch glide; aa controls speed, bb signed semitone target. With a new note and bb=00, glide from the previous note. |
| LPOF | Signed 16-bit shift of the sample's loop window, in source frames. FFFF=-1, 0100=+256. Oscillator loops retain pitch. |
| MCHD | aabb: two additional absolute MIDI notes; 00 omits a note. External instruments. |
| MDCC | aabb: MIDI CC aa, value bb, each 00-7F. External instruments. |
| MDPG | 00bb: MIDI program 00-7F. External instruments. |
| MVEL | 00bb: MIDI velocity 00-7F for subsequent notes. External instruments. |
| PAN | aabb: pan ramp, aa speed, bb position; 00 left, 80 centre, FF right. |
| PFIN | aabb: fine-pitch glide; bb is 1/128 semitone units, 80=+1 semitone, FF=-1/128. |
| PLOF | aabb: aa absolute position in 1/256ths of the sample (00 keeps position), then signed bb relative offset in the same units. Wraps within the sample. |
| PTCH | aabb: linear playback-ratio ramp; aa speed, bb signed semitone target. |
| RTRG | aabb: repeat every bb ticks, advancing the repeated region by aa ticks each repeat. bb=00 disables. Keeps the envelope running. |
| STOP | Stop all tracks; value ignored. Phrase command. |
| TABL | 00bb: start table bb, including on a held note. |
| TMPO | Hexadecimal BPM, 0029-018F (41-399); 0000 leaves tempo alone. Phrase command. |
| VOLM | aabb: volume ramp, aa speed, bb target; 00 silent, FF full. |

Volume, pan, filter and feedback ramps last `4 × aa` ticks. `VOLM 0480` moves the held sound to about half volume over 16 ticks. `VOLM 0080` sets that volume immediately. A PocketTracker tick is 1/12 of an ordinary phrase row. LGPT sound commands run in tables as well as phrases where the current engine has the relevant capability. Sample playhead/loop/retrigger operations are principally for SAMPLER and DRUM KIT; use WPOS/WSPD for WAVETABLE and the existing granular controls for grain scheduling. MIDI commands belong in phrases on EXTERNAL instruments. Sequence-global commands are labelled above. ARPG advances on the native playback tick.

### Sample seeking and scanning

* `PLOF 8000`: jump to halfway through the sample without triggering another note.
* `PLOF 0001`: move forward 1/256 of the sample.
* `PLOF 00FF`: move backwards 1/256. `PLOF 0000` leaves playback untouched.
* `RTRG 0004`: repeat the same four-tick region.
* `RTRG 0104`: repeat every four ticks while advancing one tick each repeat: a slow scan through the recording.
* `RTRG 0204`: advance two ticks per four-tick repeat.
* `RTRG 0404`: advance the whole region each time, equivalent to normal progression.
* `RTRG 0804`: scan forwards faster by skipping ahead at each repeat.
* `RTRG 0000`: disable repetition and continue normal playback.

The scan follows the current playback rate, including pitch changes. One-shots end at their sample boundary; use a looping instrument for continuous playback. RTRG does not restart the amplitude envelope or table.

## WAVETABLE

Select type WAVETABLE and LOAD a WAV containing consecutive single-cycle frames. FRAME selects 32, 64, 128, 256, 512, 1024, 2048 or 4096 samples per cycle. POSITION morphs smoothly through the frames; SCAN 80 is stationary, lower values reverse, higher values scan forwards. Pitch stays tied to the note while frame position changes. Stereo files are supported.

`WSIZ` selects frame size (00-07), `WPOS` selects position (00-FF), and `WSPD` selects scan speed (80 stationary). These work on held notes. Common amplitude envelope, polyphony, modulation and FX sends remain available. Factory preset **R14_Wavetable_Morph** includes a 16-frame, 2048-sample example.

## DRUM KIT

Select DRUM KIT, select PAD 00-0F, then LOAD a sample into that pad. Repeat for the other pads. The SAMPLE row names the selected pad's file. Instrument audition plays the selected pad.

BASE NOTE defaults to C-2 (MIDI 36). C-2 triggers pad 00, C#2 pad 01, through D#3 for pad 0F. Each pad has TUNE, FINE, LEVEL, PAN, START, END, CHOKE and REVERSE. Choke 00 disables choking; pads in the same nonzero group cut one another off. Kit-wide effects and amplitude settings remain on the instrument. Poly mode defaults on when creating a kit.

Each kit uses one packed stereo PCM allocation; loading a replacement rebuilds it outside the audio thread. Source sample rates are converted to the current device rate. A failed replacement keeps the old kit. Kits are limited to 128 MiB of decoded stereo PCM. Keep the source sample files with your projects; paths and pad settings are saved in projects and instrument presets. Factory preset **R14_Drum_Kit** includes 16 original example sounds, with closed/open hats sharing a choke group.

## Reference

Command syntax was checked against the official LittleGPTracker source:
https://github.com/djdiskmachine/LittleGPTracker
Revision `0b09128a6df92564406e7e6b5fdf3ff430df845b`, especially `CommandList.cpp`, `SampleInstrument.cpp`, `Player.cpp` and `TablePlayback.cpp`.
