# PocketTracker 3 R6

9 November 2026. Cumulative update to the working R5 build for ARM64 PortMaster / RG28XX.

## Four-note phrase tracks

On a PHRASE note cell, hold SELECT and tap A to show N1 / V / I / N2 / N3 / N4. Repeat to return to NOTE / V / I / FX1 / FX2 / FX3. Notes and FX remain saved and continue playing in either view. Velocity, instrument and row FX are shared by the four notes. Copy, cut, paste, delete and fills operate on the visible columns.

An OFF in a four-note phrase releases that lane; KIL cuts the whole track. Extra-only rows play correctly. Chords override the instrument's MONO allocation setting; its gate and the engine's shared voice cap still apply. ARP and RPT act on the first pitched note, so use the four explicit lanes for independent chord movement. External MIDI also sends the four notes with separate lane gates.

## Independent transpose patterns

On CHAIN, SELECT+A in TSP toggles LINK / FREE. Move right from TSP to edit TSP MODE, LENGTH and RATE with A+D-pad. LENGTH is 1-16 positions and RATE is 1-768 ticks, displayed in decimal. Twelve ticks equal one ordinary phrase row. For a five-against-sixteen cycle, choose FREE, LENGTH 5, RATE 12, then edit the first five TSP values, including those beside empty phrase references.

The transpose playhead runs across phrases and repeats of the same chain. A different chain or a transport restart resets it. Each triggered note uses the transpose at its onset; sustained notes are not retuned between triggers. LINK retains the original per-phrase transpose behaviour.

## Instrument table automation

Every instrument has AUTOMATION directly below NAME. Hold A with LEFT/RIGHT to choose YES or NO; R+RIGHT opens its table. YES advances the table once per triggered phrase row or incoming MIDI note, with a separate cursor for each track/instrument or MIDI part. A four-note phrase chord advances once. Empty rows and probability-skipped notes do not advance it. HOP and THO can loop each table lane independently. Transport restart resets the cycle.

Table transpose, volume and parameter commands apply before matching phrase commands, which take precedence. Auditions also advance a trigger cursor. This is LGPT-style per-trigger automation. NO preserves the existing timed table path: TIC 00 is its legacy per-trigger setting; TIC 0C is one ordinary phrase row on engines supporting timed tables. YES ignores TIC speed changes.

## Eight-part MIDI sound module

Open PROJECT > MIDI, select INPUT, then set MODE to MODULE. Press A on PARTS. Each part has ENABLE, INST, CHANNEL, LOW, HIGH, TSP, LEVEL, PAN and VOICES. All parts are saved in the project. SINGLE restores the original selected-instrument keyboard mode.

- **Layers:** enable several parts on the same channel or ALL, with overlapping note ranges.
- **Splits:** set adjacent inclusive ranges. HIGH 59 and LOW 60 split at MIDI middle C.
- **Multiple channels:** give parts different receive channels, displayed as 01-16. ALL accepts every channel. An EXTERNAL instrument sends on its own instrument output channel.
- **Expression:** velocity follows the existing VELOCITY switch. CC64 sustains released keys; pedal-up releases them. CC123 releases held keys, CC120 cuts them, and PANIC stops internal/external notes and playback.
- **Allocation:** each part uses its matching mixer track and allocates 1-4 notes. When full, the oldest note in that part is replaced. Existing engine voice caps are shared across parts; 8 parts does not guarantee 32 simultaneous voices on every engine.

Try MIDI_Layers_Demo.ptp, MIDI_Split_Demo.ptp or MIDI_Channels_Demo.ptp with transport stopped. Load other patches or samples into the selected instrument slots as usual. MIDI input does not record into phrases. Part edits release its held notes. Instrument AUTOMATION works independently in each part. Raw pitch-wheel and program-change messages go to EXTERNAL instruments; internal synth controls use existing MIDI CC mappings.

## LIVE and stopping fixes

LIVE now restores silent/playing state when a queued stop is rescheduled, accepts launches on stopped channels, and recovers from standalone Phrase/Chain playback. START queues a cell for the chain boundary; a second press promotes it to the next phrase boundary. R+START queues a track stop. L+START on SONG queues the whole scene.

In CHAIN, PHRASE, TABLE, GROOVE, SCALE, INSTRUMENT, INST.POOL and MODS while LIVE is enabled, START launches the remembered song cell and R+START queues that track's stop. From stopped, R+START launches the remembered scene. Normal SONG-mode preview controls are retained. KIL now applies the short cut fade to all native synth families.

## Retained R5 work

33 MD percussion models, 10 MNM synth models, their contextual parameter FX, all earlier engines, 115 named native presets, the tone catalogue, MIDI device recovery, independent playback/capture routing, explicit USB PCM input choices, visible input/recording feedback and direct take loading into the original Sampler or Granular instrument are included. No Elektron ROM or firmware files are required.

## Installation and compatibility

Extract pockettracker3_r6.zip into the device's usual roms/ports folder. Its two top-level items are PocketTracker 3 R6.sh and pockettracker3_r6/. The compiled program shows PT3 R6 in PROJECT. Close the applications and back up your projects before copying wanted R5 data into the new data folder.

Older R5 projects load with the new features off and their previous behaviour. Earlier experimental R6 chord and transpose field names are also accepted; row rates are converted to ticks. AUTOMATION YES now uses per-trigger playback. Earlier settings.json-based MIDI performance setups should be configured in PARTS and saved in a project. R5 cannot reproduce new four-note, independent-transpose or module settings; keep original project copies when moving between versions. The complete source, vendored dependencies, automated build workflow, updated illustrated manual and validation logs accompany this release.

The actual ARM64 executable was cross-compiled at the glibc 2.31 / SDL 2.0.18 compatibility floor and exercised under QEMU. Host and ARM64 integration checks cover the new features and retained audio/MIDI routing. Physical RG28XX performance and a real P-6 connection still require device testing.
