# PocketTracker 3 R7

R7 builds on the R6 sequencer, MIDI module, capture and native synth release.
Install `pockettracker3_r7.zip` beside existing editions; launch **PocketTracker 3 R7**.
The complete source, build workflow and illustrated manual accompany the release.

## Piano roll and shared notes

On PHRASE, **SELECT+B** flips tracker/piano roll. SELECT+A still toggles chord/FX
columns in the tracker and switches to automation in the piano roll. Both views
share the same phrase data. Four note lanes support overlapping notes, individual
tick lengths and velocities. Each onset row shares an instrument. The editor
refuses a fifth overlap and preserves hidden FX. Clipboard, fill and project saves
carry note metadata. Old phrases inherit their original gates and velocities.

D-pad moves time/pitch; A inserts/selects; A+D-pad moves notes. B+LEFT/RIGHT changes
length by a row, L+LEFT/RIGHT by one tick. B+UP/DOWN changes velocity. A+B deletes,
L+A copies, L+B pastes and L+R undoes/redoes. L+UP/DOWN changes the row instrument.

The automation graph edits one existing phrase FX slot. A+UP opens the contextual
picker, B+LEFT/RIGHT chooses the slot, A writes a point, UP/DOWN changes by 16 and
A+LEFT/RIGHT by one. L+RIGHT interpolates between matching points while preserving
other commands; A+B clears. Playback uses these authored step commands.

## DMG waveform drawing

SELECT+A on DMG opens its graphical wave editor. Sixteen banks each contain 32
samples quantized to 4 bits. Draw with the D-pad, paint with A+LEFT/RIGHT, rotate,
invert, smooth, copy/paste and undo. B returns. Wave changes reach held voices and
all banks are saved with instruments and projects.

## Handpan excitation

The original struck default is preserved. EXCITER selects STRUCK, PLUCKED, BOWED
or BLOWN. Pressure, contact/pick width/bow/air motion, noise and tone shape the
excitation; sustained modes also have attack. HXM/HPR/HSP/HNO/HXT/HAT expose these
controls in phrase FX and per-trigger automation tables. Set AUTOMATION YES for
Handpan table control; its legacy fast timed-table path is not extended here.
Bowed and blown voices sustain while held, including beyond thirty seconds.

Four new named patches expand the canonical tone bank from 115 to **119**:
Hammered Steel, Wire Pluck, Rosin Bowl and Breath Vessel. The earlier additional
factory presets remain. The catalogue and audition WAV identify all 119 patches.

## USB peripheral audio and MIDI

PROJECT > AUDIO I/O > USB DEVICE creates an owned Linux USB gadget where firmware
supports it. USB CHECK probes without creating a gadget. It refuses to replace
another app's gadget; on KNULLI first set the system USB mode to OFF.

The checked KNULLI H700 source supports bidirectional MIDI and stereo 44.1-kHz
PCM16 audio sent from PocketTracker to a computer. A compatible UAC2/UAC1 kernel
enables duplex audio at 48 kHz. The app detects the available profile and selects
its ports, restores previous routes when stopped, and cleans up its own gadget
on exit. An audio-source-only kernel cannot receive host audio. No firmware flash
is included. Physical RG28XX enumeration, cables, drivers and real-time load still
need testing on the handheld; software and emulated tests are described in
`VALIDATION_R7.md`.

See `R7_EDITORS_HANDPAN_GUIDE.md`, `USB_DEVICE_MODE_GUIDE.md` and the illustrated
manual for full controls. The FX registry now contains **191** entries. The six
new controller IDs extend the existing widened controller bus; existing effect
codes, schema 3 note payload layout and older project fields are retained.
