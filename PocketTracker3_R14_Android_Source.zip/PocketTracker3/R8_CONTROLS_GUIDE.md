# PocketTracker 3 R8: new controls

| Where | Gesture / setting | Result |
|---|---|---|
| Phrase note grid | SELECT+UP | Open/close the existing three row FX slots over the notes |
| Row FX overlay | A+UP | Open contextual FX picker; release A to apply |
| Row FX overlay | A+LEFT/RIGHT; B+UP/DOWN | Value by 1; by 16 |
| FX picker | L / R shoulders | Previous/next tab, with wrapping |
| Phrase or Chain | SELECT+R | Arm/disarm MIDI note recording |
| Piano roll | B tap | Edit toolbox: selection, copy, cut, paste, duplicate, delete, undo, redo |
| Piano roll | A+D-pad | Move/transpose the selected note or selection |
| Piano roll | B+LEFT/RIGHT; L+LEFT/RIGHT | Length by 12 ticks; by one tick |
| Piano roll | B+UP/DOWN | Velocity by one |
| Piano roll | SELECT+A | Focus graphical FX automation |
| Instrument preset LOAD | Current TYPE | Browser shows only presets whose stored engine matches |
| Settings > Theme | A+LEFT/RIGHT on name | Cycle all 26 palettes |
| Theme LOAD | .ptt / .svg / .xml | PocketTracker / Hundred Rabbits / LGPT colour import |
| Audio I/O > Input/Output | A on device row | Reconnect/refresh |

## MIDI recording

Select INPUT under PROJECT > MIDI. Arm PHRASE to record into its selected row,
or CHAIN to start at row 00 of the selected phrase reference. Existing notes and
FX stay in place. The instrument is the selected note row's I or the last edited
instrument. Up to four held notes fit; no note stealing occurs in the editor.
Monitoring uses that instrument on one four-voice mixer track while armed, then
restores normal keyboard/module routing.

While stopped, keys enter one chord and releasing all of them advances one row.
Sustain CC64 delays that advance. Gate length uses the piano insertion length,
normally twelve ticks. CHAIN advances across consecutive filled phrase refs and
stops at its end; standalone PHRASE wraps. Longer existing notes can fill all
four lanes, in which case the recorder reports a full row and preserves them.

While playing, the selected track playhead supplies the phrase and nearest row.
Velocity and released duration are saved. The normal tick duration follows tempo;
live gate lengths cap at 255 ticks. The UI thread authors the phrase from
messages timestamped by the existing audio-thread MIDI drain. It does not write
project data on the audio thread. Lookahead protects the current monitored note
from being scheduled a second time. Future loops play the recorded phrase.

Stop finalizes gates; arm stays on for step entry. Reopening/disconnecting the
MIDI port disarms. L+R in PHRASE/CHAIN undoes the last take before another manual
project edit. A manual edit invalidates take undo to protect that work.
Referenced phrases remain shared: clone first for a separate variation.

## Piano roll editing

B opens the toolbox on release, so B+direction still edits length/velocity.
SELECT AREA starts at the cursor; D-pad extends a rectangle, A finishes and B
cancels. Selection uses note onsets in the rectangle. SELECT ALL and CLEAR
SELECTION are also available. Group moves, transpose, lengths and velocity use
the same shortcuts as individual notes.

COPY/CUT use the selection, or the note under the cursor. PASTE anchors the
first onset and lowest pitch at the cursor, preserving intervals, velocities,
lengths and instruments. DUPLICATE places a copy after the selected span. DELETE
and A+B remove selected/cursor notes. FX are untouched. A group operation either
succeeds in full or changes nothing when blocked by phrase edges, four occupied
lanes or incompatible instruments sharing an onset row.

UNDO/REDO has 32 snapshots during the current piano session; L+R also undoes.
Leaving/re-entering piano roll or changing phrases clears piano history.
Onsets remain on sixteen phrase rows. Lengths can be edited at one normal tick
resolution, and the viewport scrolls through pitches. Four overlapping lanes
and a shared instrument per onset row are the underlying tracker model.

See the illustrated manual for the new screenshots, and THEMES_GUIDE.md,
AUDIO_CONNECTIONS_R8.md and COMBHIT_GUIDE.md for the other changes.
