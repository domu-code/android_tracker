# PocketTracker 3 R8 - 0.11.0

- Rebuilt Combhit as an input-envelope-triggered bank of four tuned resonators,
  with useful dB threshold, transient retriggering, audible wet replacement,
  bounded feedback and visible envelope/hit feedback. Added tracker dry/wet demo.
- SELECT+UP opens the three row FX slots over four-note entry without changing
  notes. L/R shoulders switch FX-picker tabs with wrapping.
- SELECT+R arms MIDI note recording in PHRASE/CHAIN: stopped step chords or live
  nearest-row capture, velocities, tick gates, sustain, chain advance and take undo.
- Piano B toolbox adds area/all selection, group edits, copy/cut/paste, duplicate,
  delete and 32-step undo/redo. Tracker and piano continue to share phrase notes.
- Preset LOAD filters by the selected instrument engine, using file metadata.
- Twenty adapted MIT Hundred Rabbits palettes plus PIGGY PINK/LIME; 26 total.
  Theme LOAD accepts .ptt, Hundred Rabbits .svg and LGPT .xml colour files.
- USB audio retry fixes preserve the requested device after failure and separate
  output/input recovery. Added PCM negotiation fallback and T-8/Koala setup guide.
- Retains R7's MD/MNM engines, 119 canonical presets, handpan exciters, DMG wave
  editor, MIDI layers/splits, independent transpose, table automation and LIVE fixes.

Install pockettracker3_r8.zip beside earlier releases. While apps are closed,
back up and copy old data into pockettracker3_r8/data to migrate your work.
The Combhit sound changes intentionally for songs that enable it; its parameter
IDs and saved fields remain compatible. New note metadata and themes should be
edited with R8 to avoid older versions discarding unsupported fields.

See R8_CONTROLS_GUIDE.md, COMBHIT_GUIDE.md, AUDIO_CONNECTIONS_R8.md, THEMES_GUIDE.md,
the illustrated manual and VALIDATION_R8.md for controls, evidence and limits.
