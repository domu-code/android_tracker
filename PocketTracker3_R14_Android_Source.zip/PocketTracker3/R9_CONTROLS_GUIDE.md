# PocketTracker 3 R9 controls

## Four-note row FX

SELECT+UP opens the three existing row FX slots over the four-note grid.
Hold A and use LEFT/RIGHT for -/+1, UP/DOWN for +/-16. A alone does not open
a menu. A+B clears only the selected FX slot; B returns to the note grid.

To choose a command, hold A, tap SELECT, then release SELECT while keeping A
held. SELECT first then A also works. A+D-pad navigates the picker, L/R switches
its tabs, and releasing A commits. This explicit chord avoids the old A-press
conflict. The ordinary tracker FX-type cells keep their original A+UP picker.

## Five sends

Every internal instrument page has REV, DEL, TAPE, COMB and LOFI send amounts.
The new controls are below the existing instrument parameters. The mixer has
five send rows across its eight track columns and five return levels underneath.
The track contribution adds to the note's instrument/FX send, capped at FF.
The new character sends and all mixer track contributions are post-fader/mute.
The older sampler instrument REV/DEL tap retains its original pre-fader routing.

Tap A on a send or return to open its effect controls. Hold A+D-pad to edit its
level. New return levels default to FF: raising a send is immediately audible.
00 on a return silences it. REV/DEL keep their existing mute/solo gestures;
the character returns use their level controls. R+B/R+A on a track send row
still mutes/solos that track.

The shape parameters are shared with the original master inserts. Leave master
WET at 00 for selective send processing. Raising master WET additionally
processes the whole mix. Sends are parallel wet signals and can raise mix level.
No direct external-input-through path is added: record into Sampler/Granular.

## Optional DADSR amplitude envelope

The bottom of every internal instrument page has AMP ENV and LOOP toggles,
then DLY, ATK, DEC, SUSTAIN and RELEASE. Existing presets load with AMP ENV OFF.
Enable it to shape any audio engine, including Sampler, Granular and SoundFont.
Each polyphonic note owns its own envelope. Existing source/LPG/physical/drum
envelopes continue to shape the sound before this additional amplitude control.

Time controls: 00 is instant; 01-FF is an exponential 1 ms-30 seconds.
SUSTAIN is 00 silent to FF full gain. Gate expiry, OFF or MIDI note release
starts RELEASE from the current level. Sampler loops continue through release.
LOOP repeats DLY -> ATK -> DEC -> RELEASE while held; SUSTAIN is the decay
endpoint. Releasing a looping note stops the loop and completes release.

For a simple pulsing synth: choose Braids, GATE 00, AMP ENV ON, LOOP ON,
DLY 00, ATK 20, DEC 80, SUSTAIN 70, RELEASE 70. End it with OFF or MIDI release.
An envelope cannot extend a naturally finished source: select a sample loop or
sustaining synth for long pads. EXTERNAL MIDI has no local audio envelope.

## Comb tuning envelope

Combhit now uses the hit envelope to sweep its resonator tuning, without gating
the wet amplitude. DAMP remains a low-pass in the feedback path. FDBK controls
ringing; DECAY controls how quickly the pitch sweep returns to resting TUNE.

ENV TUNE / CEN is bipolar: 00 = -48 semitones, 80 = no sweep, FF = +48 semitones.
Positive values start above TUNE and fall; negative values start below and rise.
Extreme low pitches are limited by the delay buffer. THR still controls hit
sensitivity and ENV/HIT show the detector and sweep response.

Start with TUNE 50, FDBK D2, THR 50, DAMP 3C, DECAY B4, ENV TUNE D0.
Use COMB send 90 with the mixer COMB return FF and master comb WET 00.
Alternatively, use master WET C0 on FX_Comb_Listen.ptp. Compare CEN 30/80/D0.

## Commands

| Commands | Meaning |
|---|---|
| REV / DEL | Current note reverb / delay sends |
| TSN / CSN / LSN | Current note tape / comb / lo-fi sends |
| RWT / DWT / TSW / CSW / LSW | Shared reverb / delay / tape / comb / lo-fi returns |
| RDC / RSZ / RDM | Reverb decay / size / damping |
| RPR / RWD / RMO | Reverb predelay / width / modulation |
| TIM / DFB / DTN / DWB | Delay time / feedback / tone / wobble |
| DPG / DSR | Delay ping-pong (00 OFF, 01 ON) / delay-to-reverb |
| CEN / CDC / CTN | Comb tuning-envelope depth / sweep decay / resting tuning |
| AEN / ALP | DADSR enable / looping (00 OFF, 01 ON) |
| ADL / AAT / ADC / ASU / ARL | DADSR delay / attack / decay / sustain / release |

Note commands reset with a new note. Shared bus commands latch until changed
or STOP restores the authored settings. Continuous new controls support AUS/AUF;
the ON/OFF toggles are direct commands. Song and table authoring use the same
registry; incoming/preview trigger tables also carry the new commands.

Full-mix export includes the new returns. Stem export adds _tape, _comb and
_lofi returns when instrument, track, phrase or table sends use them.

See the R9 illustrated manual for all 218 registry entries and native UI views.

## Creative effects and detailed help

See CREATIVE_EFFECTS_R9.md for Beads, DIFFOLD, the morph filter, input envelope destinations and the dedicated effect tabs. SELECT help now follows each added control and the active MD/MNM parameter label.
