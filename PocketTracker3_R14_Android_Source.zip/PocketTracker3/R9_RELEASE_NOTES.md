# PocketTracker 3 R9 - 0.12.0

- Fixed four-note row FX: A never opens the menu on press. A+UP/DOWN changes
  value by sixteen; A+LEFT/RIGHT changes by one. SELECT+A opens the command
  picker in either press order, with shoulder tabs and release-to-choose.
- Added separate Tape, Comb and Lo-Fi wet buses. Every internal instrument
  has send levels; the mixer adds five track send rows and five return levels.
- Added optional per-note DADSR amplitude envelopes to all fourteen internal
  audio engine paths. Delay, attack, decay, sustain, release and held looping
  are saved with instruments/presets and have phrase/table commands.
- Changed Combhit to use its transient envelope for bipolar tuning sweeps.
  Damping remains feedback tone; the wet signal is not amplitude-gated.
- Added 27 commands: character sends/returns, DADSR, comb envelope depth and
  the main reverb/delay controls. Continuous controls support AUS/AUF.
- New send buses appear in full mix and stem export. Idle buses sleep.
- Retains R8 recording, piano editors, MIDI module, USB recovery, engine
  preset filtering, themes, instruments and factory tone bank.

R9 installs beside R8 as PocketTracker 3 R9.sh plus pockettracker3_r9/.
Close both applications before backing up and copying data into R9/data.
New sends default to zero and the added amplitude envelope defaults OFF.
Combhit intentionally sounds different when enabled. R9-only fields should
be edited in R9; older versions may discard fields they do not understand.

Read R9_CONTROLS_GUIDE.md and VALIDATION_R9.md for gestures and verification.
Physical handheld CPU, controller and USB checks still require the device.

Additional R9 effects and help:
- Original Beads DSP in stereo digital mode, host-rate adapter and thirteen controls.
  Classic Cloud, Micro Delay, Shimmer and Long Cloud presets; Beads_Cloud_Demo.ptp.
- DIFFOLD-inspired all-pass diffusion/folding, three presets, and a Loom-style
  continuous LP/BP/HP/notch resonant filter.
- Per-effect input-triggered AHD envelopes on all nine processor sections,
  threshold, signed depth, destination picker, trigger counter and activity meter.
- Per-effect command tabs, including all continuous processor controls, freeze,
  presets, reverb algorithms/input EQ and master processing controls.
- 314 additional parameter-specific SELECT help cards, with model-dependent
  MD/MNM labels, piano toolbox actions, MIDI parts and audio connection help.
- 260 registry entries including the empty slot (259 commands). Table effect
  identities now retain the full command ID through atomic publication; existing
  saved IDs are unchanged. The new send/amp controllers avoid the R8 handpan IDs.

CREATIVE_EFFECTS_R9.md gives all new parameter mappings and starting settings.
