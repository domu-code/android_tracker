# PocketTracker 3 R14

See [R14_README.md](R14_README.md) for installation, all 27 LGPT commands, sample scanning, and the WAVETABLE and DRUM KIT engines.

Build on a desktop with `bash build-r14.sh desktop` (SDL2 development headers required). Use `bash build-r14.sh native` for the engine and editor libraries. To make an ARM64 PortMaster package against glibc 2.31, run `tools/build_r14_arm64.sh` in an Ubuntu 20.04 container with the R13.1 installer supplied as the asset ZIP.

# PocketTracker 3 R11 - 0.15.0

See [R11 release notes](R11_RELEASE_NOTES.md), [controls](R11_CONTROLS_GUIDE.md), [validation](VALIDATION_R11.md), and [build steps](BUILD_R11.md). R11 adds independent chain and phrase-slot speeds, long tied notes, bar-fraction time notation, five audio-quality modes and expanded MIDI mapping.

# PocketTracker 3 R9 - 0.12.0

Install pockettracker3_r9.zip, or read [R9_CONTROLS_GUIDE.md](R9_CONTROLS_GUIDE.md) and [BUILD_R9.md](BUILD_R9.md).
R9 adds five effect sends, loopable DADSR amplitude envelopes, comb tuning envelopes and corrected row-FX controls.

# PocketTracker 3 R8

Envelope-triggered Combhit, MIDI phrase recording, a piano edit toolbox, 26
themes, filtered presets and direct FX tab navigation.

Shared tracker/piano-roll note editing, graphical phrase FX automation, a 32-step
4-bit DMG wave editor, four Handpan excitation modes, and firmware-aware USB
audio/MIDI peripheral mode. R6 four-note phrases, independent transpose loops,
per-trigger tables, eight-part MIDI layers/splits and LIVE fixes remain included.
The canonical native bank now has 119 named presets.

Read [new controls](R8_CONTROLS_GUIDE.md), [Combhit](COMBHIT_GUIDE.md),
[audio connections](AUDIO_CONNECTIONS_R8.md), [themes](THEMES_GUIDE.md),
[R8 release notes](R8_RELEASE_NOTES.md), [editor and Handpan controls](R8_EDITORS_HANDPAN_GUIDE.md),
[USB device mode](USB_DEVICE_MODE_GUIDE.md), [tone list](PRESET_TONE_LIST.md) and
[validation](VALIDATION_R8.md). Install `pockettracker3_r8.zip` under PortMaster's
ports folder; it has its own launcher and data directory. Copy older data while
both apps are closed, keeping the original backup.

The R8 source ZIP is self-contained, including SDL build support, synthesis DSP,
codecs, tests, factory patches and the illustrated manual generator. Use the
matching `build-pockettracker3-r8.yml` workflow with its exact source ZIP checksum.
See `BUILD_R8.md` for a desktop build and the core verification commands.

PocketTracker retains its included GPL-3.0 licence and third-party notices.
Braids, Rings, Plaits and stmlib retain their original MIT notices; Open303 and
the independently written MD/MNM-style voices retain their supplied MIT notices.
See LICENSE, CREDITS.md and docs/licenses/THIRD-PARTY-NOTICES.md. Original upstream
background is preserved in docs/UPSTREAM_README.md.
