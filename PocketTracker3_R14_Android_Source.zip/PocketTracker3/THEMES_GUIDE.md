# R10 palettes

There are 42 built-in palettes, including 16 additional original dark/light themes:
Phosphor, Deep Sea, Ink Violet, Safety Orange, Rose Terminal, Petrol, Midnight Gold,
Ultramarine, Paper Ink, Mint Paper, Blueprint Light, Lavender Paper, High Contrast,
Ochre Screen, Ice Field and Ruby Grid. New palettes adapt label/value contrast.

# Community palettes

Twenty palettes are adapted from Hundred Rabbits Themes, https://github.com/hundredrabbits/Themes, pinned at commit 8ac49d6aa195a150255dd6f711aebe0b6bddc964. The source SVG files and the complete MIT licence are in native/vendor/100r-themes. Colours are mapped from the nine theme roles to tracker roles, with contrast adjustments for legible labels, cursor cells and light palettes. The source SVG colours are preserved.

PIGGY PINK and PIGGY LIME are original PocketTracker palettes inspired by the LGPT aesthetic; they are not copies of an LGPT theme. LOAD also imports LGPT XML colour configurations and Hundred Rabbits SVG palettes, without running SVG scripts. Save an imported theme as .ptt to retain your edits.

SETTINGS > THEME > name: A+LEFT/RIGHT cycles all 26 built-ins. LOAD accepts .ptt, .svg and .xml from the Themes folder. The default stays BLUE.
