# PocketTracker 3 R7: USB device audio and MIDI

## Connect the handheld to a USB host

On a supported Linux/PortMaster firmware, PocketTracker can present audio/MIDI
endpoints to a computer or other external USB host. This is separate from plugging
a keyboard, P-6 or USB interface into the handheld in host mode.

1. Save your work. In KNULLI, set the system USB mode to OFF so its ADB gadget
   releases the USB controller. The helper refuses to take over a busy gadget.
2. Connect the RG28XX data/OTG USB port to a computer with a data-capable cable.
3. In PocketTracker choose PROJECT > AUDIO I/O > USB CHECK and press A. This is
   a probe, not a switch. A root-capable PortMaster session is required for setup.
4. Choose USB DEVICE and press A. Wait for the status and device enumeration.
5. In the computer choose PocketTracker's MIDI destination and audio input. To
   play sounds from a keyboard routed through the computer, send its MIDI to the
   PocketTracker port. PROJECT > MIDI > MODE=MODULE gives the eight-part layer,
   channel and split editor from R6; the other MIDI mode plays the selected patch.
6. Turn USB DEVICE off before using the handheld as a USB host again. App routes
   are restored. Normal app exit also removes this session's owned gadget.

The app selects matching audio/MIDI gadget ports automatically as they appear.
If it reports SELECT AUDIO/MIDI PORTS, use AUDIO I/O and MIDI to select them
manually. MIDI same-port thru is suppressed to avoid a feedback loop; note input
and sequencer/external MIDI output still work. Device mode is opt-in each session.
Stop recording before switching modes. Disconnect/reconnect the cable if the
host has cached an old descriptor after changing firmware/profile.

## What each status means

Directions in this table are from PocketTracker's point of view.

| Status | Audio | MIDI | Kernel capability |
|---|---|---|---|
| USB AUDIO IN-OUT + MIDI | Stereo 48-kHz PCM16 both ways | Both ways | Compatible UAC2/UAC1 gadget |
| USB AUDIO OUT + MIDI | Stereo 44.1-kHz PCM16 to host | Both ways | Android-style audio_source gadget |
| USB MIDI IN-OUT ONLY | None | Both ways | MIDI gadget only |
| USB HOST MODE | Normal handheld playback and host interfaces | Existing external ports | Device mode off |
| NO USB DEVICE CONTROLLER | No peripheral endpoint can be created | None through this route | Missing UDC/port/firmware support |
| USB BUSY | Existing system gadget kept intact | Existing system route | Disable KNULLI USB mode first |

MIDI is not an audio stream. A MIDI cable sends keys/clock/control; the audio
endpoint carries PocketTracker's rendered mix. In a duplex profile, host audio is
available as a capture input for the recorder/Sampler/Granular. It is not
implicitly sent through to output. A source-only profile cannot receive host audio.

The device uses one USB controller in peripheral mode. An ordinary USB keyboard
is itself a peripheral and needs a host; connecting two peripherals directly is
not a host. Route a keyboard through the computer, or use a separately supported
MIDI interface/controller path. A powered hub does not change USB roles.

## Checked firmware source and optional duplex build

The KNULLI H700 configuration checked for this release enables `USB_GADGET`,
`USB_CONFIGFS`, `USB_CONFIGFS_F_MIDI` and `USB_CONFIGFS_F_AUDIO_SRC`, while UAC1 and
UAC2 are disabled. Its Orange Pi 4.9 audio_source function exposes an ALSA playback
PCM named `USB gadget audio`, card `audio_source`, at stereo 44100 Hz, 16 bit.
Consequently the supplied app can attempt MIDI in/out plus audio sent to the host
on that firmware, but it cannot create a receive-audio direction that the kernel
has not implemented. The installed firmware may differ from the checked source.

An optional `shell/portmaster/h700-usb-duplex.config` fragment records the relevant
UAC2 options for a custom firmware builder. Rebuild the corresponding KNULLI H700
kernel/firmware with its own build system and verify the board's USB device role.
This fragment is not a ready-to-flash image and no firmware is modified by the
PortMaster installation. A UAC2-enabled build is still subject to endpoint, host
and firmware compatibility testing.

The app helper tries duplex UAC2, then compatible duplex UAC1, then audio_source,
then MIDI-only. It owns only `usb_gadget/pockettracker`, uses one MIDI input and
output, checks for another bound gadget and reports setup failures. The Linux
prototype VID/PID is used for this development build; a distributed hardware
product should use an appropriately assigned USB identity.

Primary implementation sources:

- KNULLI H700 configuration: https://github.com/knulli-cfw/knulli-linux/blob/knulli-main/board/allwinner/h700/linux-sunxi64-legacy.config
- KNULLI USB gadget lifecycle: https://github.com/knulli-cfw/knulli-linux/blob/knulli-main/board/allwinner/h700/fsoverlay/etc/init.d/S28usbmode
- H700 board/kernel revision: https://github.com/knulli-cfw/knulli-linux/blob/knulli-main/configs/knulli-h700.board
- Firmware kernel audio source: https://github.com/orangepi-xunlong/linux-orangepi/blob/orange-pi-4.9-sun50iw9/drivers/usb/gadget/function/f_audio_source.c
- Linux gadget configuration: https://docs.kernel.org/usb/gadget-testing.html

Automated tests use a simulated configfs and mock ALSA enumeration, plus the real
SDL audio conversion/capture code. ARM64 code is also run under QEMU. Physical
RG28XX USB enumeration, the connected host's driver behaviour, endpoint audio and
real-time CPU load have not been tested here. The helper remains off by default.
