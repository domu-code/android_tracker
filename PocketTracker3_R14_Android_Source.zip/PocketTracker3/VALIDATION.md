# PocketTracker 3 R7 validation

## Built and executed

- Native Release core/UI and AArch64 Release SDL application built successfully.
- The stripped AArch64 executable boots under QEMU with SDL dummy video/audio,
  loads MIDI_Layers_Demo.ptp, runs the frame loop, saves settings and exits cleanly.
- The binary links the firmware SDL dynamically. The staging check verifies its
  ARM64 ELF identity, glibc requirement (maximum GLIBC_2.29, within the 2.31 floor),
  original Mutable lookup-table signatures, release/feature labels and notices.
- PortMaster ZIP paths, executable permissions, USB helper, factory patches,
  guides, manuals, source checksum and archive integrity are verified together.

## Production-path integration checks

Host and AArch64/QEMU runs passed the editor, Handpan, USB session and existing
sequencer/MIDI/audio integration suites:

- Tracker/piano synchronization, four overlapping lanes, separate tick lengths
  and velocities, scheduled playback, real MIDI note-off gates, persistence,
  clipboard/fill metadata, interpolation, fixed FX selection, protected other FX,
  undo and contextual picker commits.
- DMG 32-step 4-bit drawing, wave-bank selection, rotate/invert/copy/paste/undo,
  preset round trips, preservation of other banks and held-note audio updates.
- Four Handpan exciters, parameter save/load, all 103 synth controller IDs,
  contextual FX visibility, phrase/per-trigger-table locks, scheduled live edits,
  31-second bowed/blown sustain, release and extreme-value finite/bounded output.
- Four-note phrase lane releases, independent transpose at three rates across
  phrase boundaries, table automation for fifteen instrument types, and LIVE
  stop/relaunch plus Phrase/Chain preview recovery.
- Eight MIDI module parts, channels, split endpoints, layers, sustain, lane
  stealing, velocity-zero note-off, route changes, PANIC and audible chords.
- All 43 MD/MNM models, phrase/table model and slot locks, live edit timing,
  save/load, contextual FX labels and absence of engine-controller MIDI leakage.
- Real SDL PCM16/PCM32/float conversion with mocked device endpoints, 44.1/48-kHz
  mono/stereo input, independent AUTO capture routing, WAV save/load, error paths,
  reconnect recovery and immediately playable Sampler/Granular recordings.

The strict R6/default-struck formula comparison is exact on the host. ARM's fused
arithmetic changes rounding slightly: maximum sample difference 0.000040607 and
RMS difference 0.000012607 on a +/-1 scale in the one-second baseline probe.
Disabling contraction makes the ARM reference comparison exact. The regression
bound is 0.0001; the original struck equations and default settings are retained.
The production build keeps its normal compiler floating-point settings.

## USB helper and routing

The shipping POSIX helper passed simulated configfs checks for duplex, audio-
source and MIDI-only profiles, non-mutating probe, start/stop, missing controller
or MIDI support and preservation of a foreign bound ADB gadget. Session tests
exercise asynchronous setup, devices appearing in different orders, ALSA naming
aliases, bidirectional MIDI selection, recording guard, feedback suppression,
route restoration and exit cleanup. No test binds the host machine's real USB bus.

## Presets and documents

All 119 canonical native presets render nonzero, finite audio within the level
bounds and survive preset serialization. The four new Handpan patches are also
listed in the tone catalogue. Earlier additional factory presets are retained.
The WAVs are rendered by the real engine.

The illustrated manual contains 116 pages and references all 191 FX registry
entries (190 commands plus the empty command). The preset catalogue has ten
pages. All pages were rasterized and visually reviewed; text geometry checks
found no text outside pages, empty pages or replacement glyphs. Screenshots use
the production native UI.

## Hardware verification still required

No physical RG28XX, P-6 or external USB host was connected. QEMU verifies target
instruction execution and software behaviour, not handheld CPU headroom, its
firmware/controller mapping, actual USB enumeration, host drivers or endpoint
streaming. Device mode is opt-in each session.

The checked KNULLI H700 source enables MIDI and the audio_source gadget: audio
sent to the host plus MIDI both ways. Receiving host audio needs a compatible
UAC2/UAC1 firmware kernel. The helper detects available functions; no firmware
flash or kernel replacement is included. See USB_DEVICE_MODE_GUIDE.md.

The complete kit includes the per-suite verification logs, build/package report,
checksums and the exact corresponding source ZIP/workflow.
