# R10 verification

Passed software checks:

- Physical button events: L/R taps, no premature unit jump during reorder or bypass,
  retained selection, classic and four-note blank-cell A insertion, A+directions,
  preserved chord notes, selector prerequisites and persistent SELECT help.
- Saved order/bypass and native parameter modulation destination round trips.
  Reordered non-linear inserts produce different audio. Bypass fades to the dry
  signal through the unchanged final limiter.
- All 168 effect recipes rendered through the actual engine at 48 kHz: finite,
  non-silent output below full scale on the test source.
- All 295 native tone recipes rendered, conservatively level balanced and saved.
  Source-preserving template persistence tested. Library files remain input dependent.
- Original Beads DSP, 44.1/48 kHz adapters, triggered comb tuning, five sends,
  14 amplitude-envelope engine paths, wide atomic table publication and FX routing.
- MIDI recording/monitoring, sustain, live timing, phrase/chain progression;
  piano selection, group editing, velocity/length, clipboard and undo/redo;
  sequencer, MIDI parts, independent audio retry/hotplug and PCM conversions.
- Host DSP/schema/interface/packaging checks. PDF pages rendered for visual review.
- ARM64 executable compiled; architecture, original DSP tables, feature markers,
  dynamic dependencies, GLIBC floor, archive CRCs and source manifest verified.

Limits: this session did not execute the ARM64 binary or test physical RG28XX,
Roland/Koala USB devices, firmware or whole-song CPU capacity. The software SDL
checks use controlled device responses and the native audio conversion code.
The included optional GitHub workflow adds ARM64 checks under QEMU when run.

See docs/validation-r10 for the exact logs, tone metrics and ABI report.
