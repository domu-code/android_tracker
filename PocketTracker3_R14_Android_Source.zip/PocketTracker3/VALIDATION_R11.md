# R11 host verification

Native Linux CMake targets `songcore`, `pt-ui`, `pockettracker` built successfully in the working environment after the MIDI, audio quality and timing changes. `run_r11_timing_quality_integration.sh` passed: bar fractions, all five mode profiles, independent tracks (1/4x versus 1x), a faster phrase override (2x), serialized song rates, legacy defaults, and held NOTE OFF across a phrase boundary. `run_r7_editors_integration.sh`, `run_r8_editors_integration.sh` and `run_r9_reactive_integration.sh` also passed.

The R6 UI navigation integration was updated to account for the inserted SPEED column and rechecked with the full source build. No cycle-accurate device CPU benchmarks, physical RG28XX testing, or validated ARM64 installer are included. The workflow provided separately performs the cross-compile and ARM64 checks on GitHub.
