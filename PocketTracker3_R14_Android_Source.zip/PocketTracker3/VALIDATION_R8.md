# PocketTracker 3 R8 validation

Native Release core/UI and AArch64 Release SDL builds compile the same source.
The installable executable is ARM64 and uses the firmware's dynamic SDL. The
package checks the glibc floor, original Mutable tables, R8 feature markers,
permissions, factory presets, themes, licences and exact source ZIP checksum.

## New behaviour exercised

- Physical button mapper: SELECT+UP row FX; A+UP/release contextual picker; shoulder
  tab wrapping without note edits; B tap toolbox versus held length modifier.
- Piano selection, group move/transpose/velocity, copy/cut/paste/duplicate/delete,
  undo/redo, blocked group transactions and preservation of row FX/instruments.
- Metadata-based preset filtering with deliberately misleading filenames.
- All 20 source theme SVG imports, 26 built-ins, dark/light text contrast, theme
  JSON round trip, LGPT XML import and invalid/incomplete file refusal.
- Real MIDI parser/host path: stopped four-note chords, velocities, unmatched
  releases, sustain, chain-reference advance/end, live playhead quantization,
  tick lengths, stop finalization, input reset, take undo and project round trip.
- Production audio drain: record arm isolates one four-voice monitor track inside
  a layered MIDI project; the chord sounds and releases without hanging notes.
- Combhit DSP at 44.1/48 kHz: quiet -38 dB input hits, threshold rejection, no
  noise generation on silence, one trigger on a steady tone, audible changes
  from all six controls and finite bounded extreme settings.
- Actual factory tracker/master-bus Combhit render: four hits, dry RMS 0.006797,
  wet RMS 0.012574, wet peak 0.137688 and change/dry energy ratio 3.65847. The
  delivered comparison plays dry for 3 seconds, silence for 0.5, wet for 3.
- Failed audio opens retain a newly selected named device across refresh/retry;
  input/output retries are independent and success cannot hide the other error.
  Real SDL PCM conversion covers float, PCM16/32, mono/stereo and 44.1/48 kHz,
  including a PCM-only open fallback, empty takes, disconnect and recovery.

The editor, comb, audio-session, retained R7 editor, independent-transpose/table/
LIVE sequencer, MIDI module and FX-dispatch suites pass on host and ARM64/QEMU.
The SDL device endpoints are simulated; the converters and WAV decoders are real.

## Retained functionality

The 43 MD/MNM models, FM/Open303/Mutable engines, Handpan exciters, 32-step DMG
wave editor, eight-part MIDI layers/splits, per-trigger tables, independent
transpose loops, LIVE recovery and 119 canonical presets remain included.
The host regression scripts and complete factory preset render check these
against the R8 build. See the kit verification logs for the individual results.

The manual has 127 pages and covers all 191 registry entries. The preset
catalogue has ten pages. Screenshots are produced by the native UI renderer;
PDF geometry and rendered pages are reviewed before packaging.

## Hardware scope

No physical RG28XX, Roland T-8/P-6, Koala phone or external USB host was attached.
QEMU validates ARM instructions and software behaviour, not real-time handheld
CPU headroom, USB enumeration, USB power, cables or firmware drivers. Audio
connection guidance follows Roland/Koala documentation and distinguishes host
from peripheral roles. Device mode remains opt-in.

A source-only H700 gadget kernel sends audio to a host and carries MIDI both
ways; capture from the host requires a compatible duplex UAC2/UAC1 kernel.
The existing helper detects available functions. No firmware flash is included.

R7's baseline Handpan precision note remains applicable: ARM fused arithmetic
can differ from strict host equations by small floating-point rounding. The
struck equations/defaults were not changed in R8. See VALIDATION_R7.md for the
baseline comparison and R7-specific tests, and the R8 logs for this release.
