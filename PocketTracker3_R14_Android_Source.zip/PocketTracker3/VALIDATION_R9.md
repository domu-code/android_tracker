# R9 validation

The delivered executable is freshly cross-compiled ARM64 code. It has not been executed on ARM64 or a physical RG28XX in this session. Production C++ DSP, sequencer, controller and UI integration tests ran natively on the host. USB tests use controlled device mocks; no attached Roland, Koala or handheld device was available.

## Passed software checks

- R9 A-button press/release event dispatch in both SELECT+A orders; holding A plus directions changes row FX values without opening a menu or damaging the four notes.
- Tape, comb and lo-fi note/track sends, separate return levels, track/mute isolation, project/preset persistence and STOP restoration. All fourteen internal audio engine paths passed independent DADSR delay, release and voice-ending checks.
- Native comb envelope: quiet-hit detection at 44.1/48 kHz, bipolar tuning trajectories, no amplitude gating, stable extremes and tracker-bus render. The tracker render changes dry RMS 0.006797 to wet RMS 0.013273, with four detected hits and peak 0.137154.
- Original Beads stereo digital DSP at 44.1/48 kHz, four presets, fully wet output and tails after source silence. The 48-kHz wet RMS values are 0.011889 Classic Cloud, 0.022042 Micro Delay, 0.023947 Shimmer and 0.024359 Long Cloud. The kit includes the rendered preset audition.
- All nine effect-envelope paths triggered in the real engine; threshold/retrigger behaviour, bipolar depth, destination selection, persistence and original knob preservation were checked. Morph filter and DIFFOLD produce finite audible output.
- All 42 added reactive-control resolutions and per-effect command tabs. A separate R9 test checks the preceding 27 send/amp/bus commands. The complete registry contains 260 entries, including the empty command.
- 314 new SELECT cards fit the full overlay. Coverage visits 598 instrument/effect cursor contexts, including model-specific machine labels. Both compact and full views use the same context resolver.
- Table effect identities above FF survive the project-to-engine path. A concurrent writer/reader test checks coherent two-word table publication. Original saved effect IDs are retained.
- A Dragonfly reverb SIZE command changes the actual Hall render. Physical size rebuild requests are coalesced on the control/offline thread; input envelopes offer only continuously supported reverb destinations.
- R8 editor/MIDI recording tests, R7 piano/DMG editor tests, R6 sequencer and fourteen-family audio tests, all 43 MD/MNM models, FM machine tables, handpan exciters, MIDI module and audio-session discovery/retry/load tests passed after the R9 changes.

## Artifact checks

The release checks the actual executable for ARM64 identity, original Braids/Rings/LXR lookup tables, R9 and new effect labels, dynamic-library dependencies and GLIBC compatibility. ZIP checks cover CRC, executable permissions, installer paths, complete source-manifest hashes and the exact source checksum embedded in the optional GitHub workflow. The illustrated manual is regenerated from native app views and the current command registry.

## Device checks still needed

CPU load with several heavy engines/effects, physical controller timing, Roland/Koala audio capture/playback, USB hotplug and USB peripheral modes must be tried on the intended Knulli device. The software tests cannot certify those hardware paths. No ARM64 runtime or QEMU pass is claimed for this local build. The optional workflow retains separate ARM/QEMU checks for a future GitHub build.
