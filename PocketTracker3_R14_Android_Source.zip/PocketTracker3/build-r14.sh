#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
MODE=${1:-desktop}
case "$MODE" in
 native) SOURCE="$ROOT/native"; BUILD="$ROOT/build/host" ;;
 desktop) SOURCE="$ROOT/shell"; BUILD="$ROOT/build/desktop" ;;
 *) echo 'Usage: bash build-r14.sh [native|desktop]' >&2; exit 2 ;;
esac
cmake -S "$SOURCE" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release -DCMAKE_POLICY_VERSION_MINIMUM=3.5 "${@:2}"
cmake --build "$BUILD" --parallel "${CMAKE_BUILD_PARALLEL_LEVEL:-2}"
