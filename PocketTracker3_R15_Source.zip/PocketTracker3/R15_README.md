# PocketTracker 3 R15 / 0.19.0

R15 is an update to our R14 PortMaster/Android engine. It **retains the PortMaster path**
`ports/pockettracker3_r13/` and the launcher name `PocketTracker 3 R13.sh` to update
existing installs without creating a second application/data folder.
PROJECT reports **PT3 R15**. It preserves R14 drum kits, wavetables, LGPT commands,
project/preset handling and the full previous engine list.

## Android changes

The original PocketTracker button PNGs are now drawn in **landscape** as well as portrait
(when available in the Android frontend). R14's custom mechanical keycap is the fallback
if a skin asset is missing. SETTINGS > ORIENTATION: AUTO, PORTRAIT, LANDSCAPE. AUTO preserves
R14 behavior (portrait with touchscreen buttons, sensor rotation when a controller is
attached). PORTRAIT and LANDSCAPE force the appropriate sensor-orientation category.

SETTINGS > BTN VIBRO already supported ON/OFF. R15 ships with **OFF by default** on
fresh installs, but existing saved settings remain respected. Button sound is separately
controlled by BTN SOUND. Android's asset skin selectors still offer DARK, NORM and TRNS.

## New four-digit effects (all can affect a sounding note without retriggering)

| Command | Value `aabb` | Operation |
|---|---|---|
| `GLCH` | `aa`: 8 to 2048 samples (mapped from 00..FF); `bb`: dry/wet | Capture the most recent audio fragment from the voice and replay it cyclically without re-recording it. `GLCH 20FF` is a short, fully wet buffer override; `0000` ends it. |
| `GRVS` | `0000` forward, `0001` reversed | Reverse the currently captured fragment while GLCH remains active. |
| `GATX` | `aa`: period in quarter-tracker-ticks; `bb`: gate duty | Amplitude gate with de-click smoothing. `GATX 08C0` roughly 75% open; `GATX 0000` disables it. |
| `TRMX` | `aa`: tremolo cycle in tracker ticks; `bb`: depth | Smooth sinelike level modulation; `TRMX 04FF` deep tremolo, `0000` disables it. |
| `PARM` | `aa`: address, `bb`: 00..FF value | Live automation of the complete exposed 103-entry synth parameter bank and the internal effect-controller groups below. |

GLCH is **per sounding voice** and stores a maximum of 4096 input frames. With GLCH
active, its buffer is held (old audio repeats); wet 00 returns to ordinary playback.
The effects are independent of sample content, so they can process oscillator voices
and samplers. Multiple voice effects can be combined. Use GLCH/GRVS/GATX/TRMX on
phrases or tables; PARM on phrases and synth tables.

## PARM address ranges

All values are authored as four hex digits. The high byte selects an existing *internal*
controller, never an external MIDI CC. The low byte holds its value. Engine-specific
parameters only affect instruments that implement them. The dedicated short effects
remain available in the FX picker as well.

| Address | Parameter family |
|---|---|
| `00`..`66` | All 103 indexed synth-parameter effects in the table below |
| `70`..`7F` | 16 bus effects controllers (reverb, delay etc.) |
| `80`..`8B` | 12 modulation-slot controllers |
| `8C`..`92` | 7 amplitude-envelope controls |
| `93`..`95` | 3 extra per-voice sends |
| `96`..`D1` | 60 reactive effects controllers |
| `D2`..`DF` | 14 global character-effect parameters |
| `E0` | Pan |
| `E1` | Filter cutoff |
| `E2` | Filter resonance |
| `E3` | Reverb send |
| `E4` | Delay send |

Addresses `67`..`6F` and `E5`..`FF` are reserved. File paths and non-numeric editor
operations are not automatable. Many global, sample and MIDI controls also retain their
pre-existing dedicated FX names; PARM is an additional indexed route, not a replacement.

### Indexed synth parameter table

| Address | Existing named FX | Example |
|---|---|---|
| `00` | `BMD` | `PARM 00xx` |
| `01` | `BTM` | `PARM 01xx` |
| `02` | `BCL` | `PARM 02xx` |
| `03` | `RMD` | `PARM 03xx` |
| `04` | `RST` | `PARM 04xx` |
| `05` | `RBR` | `PARM 05xx` |
| `06` | `RDP` | `PARM 06xx` |
| `07` | `RPO` | `PARM 07xx` |
| `08` | `PMD` | `PARM 08xx` |
| `09` | `PHA` | `PARM 09xx` |
| `0A` | `PTM` | `PARM 0Axx` |
| `0B` | `PMO` | `PARM 0Bxx` |
| `0C` | `PDC` | `PARM 0Cxx` |
| `0D` | `PLG` | `PARM 0Dxx` |
| `0E` | `DWA` | `PARM 0Exx` |
| `0F` | `DSC` | `PARM 0Fxx` |
| `10` | `DWP` | `PARM 10xx` |
| `11` | `DFD` | `PARM 11xx` |
| `12` | `DWR` | `PARM 12xx` |
| `13` | `DWD` | `PARM 13xx` |
| `14` | `DBT` | `PARM 14xx` |
| `15` | `DSM` | `PARM 15xx` |
| `16` | `DCT` | `PARM 16xx` |
| `17` | `DRS` | `PARM 17xx` |
| `18` | `HMT` | `PARM 18xx` |
| `19` | `HMO` | `PARM 19xx` |
| `1A` | `HDC` | `PARM 1Axx` |
| `1B` | `HHD` | `PARM 1Bxx` |
| `1C` | `HPO` | `PARM 1Cxx` |
| `1D` | `HCP` | `PARM 1Dxx` |
| `1E` | `HBD` | `PARM 1Exx` |
| `1F` | `HST` | `PARM 1Fxx` |
| `20` | `GPO` | `PARM 20xx` |
| `21` | `GSZ` | `PARM 21xx` |
| `22` | `GDN` | `PARM 22xx` |
| `23` | `GSC` | `PARM 23xx` |
| `24` | `GSN` | `PARM 24xx` |
| `25` | `GSP` | `PARM 25xx` |
| `26` | `DST` | `PARM 26xx` |
| `27` | `DVL` | `PARM 27xx` |
| `28` | `XMD` | `PARM 28xx` |
| `29` | `XDC` | `PARM 29xx` |
| `2A` | `XSW` | `PARM 2Axx` |
| `2B` | `XSH` | `PARM 2Bxx` |
| `2C` | `XFM` | `PARM 2Cxx` |
| `2D` | `XNO` | `PARM 2Dxx` |
| `2E` | `XCT` | `PARM 2Exx` |
| `2F` | `XDR` | `PARM 2Fxx` |
| `30` | `XAT` | `PARM 30xx` |
| `31` | `XMT` | `PARM 31xx` |
| `32` | `XRS` | `PARM 32xx` |
| `33` | `XAK` | `PARM 33xx` |
| `34` | `XPT` | `PARM 34xx` |
| `35` | `XFT` | `PARM 35xx` |
| `36` | `XLR` | `PARM 36xx` |
| `37` | `XLD` | `PARM 37xx` |
| `38` | `OCT` | `PARM 38xx` |
| `39` | `ORS` | `PARM 39xx` |
| `3A` | `OEM` | `PARM 3Axx` |
| `3B` | `ODC` | `PARM 3Bxx` |
| `3C` | `OAC` | `PARM 3Cxx` |
| `3D` | `OWV` | `PARM 3Dxx` |
| `3E` | `OTM` | `PARM 3Exx` |
| `3F` | `OSL` | `PARM 3Fxx` |
| `40` | `OAK` | `PARM 40xx` |
| `41` | `OAD` | `PARM 41xx` |
| `42` | `OVD` | `PARM 42xx` |
| `43` | `ORL` | `PARM 43xx` |
| `44` | `ODR` | `PARM 44xx` |
| `45` | `OHP` | `PARM 45xx` |
| `46` | `OSU` | `PARM 46xx` |
| `47` | `OAT` | `PARM 47xx` |
| `48` | `FMD` | `PARM 48xx` |
| `49` | `FCL` | `PARM 49xx` |
| `4A` | `FSH` | `PARM 4Axx` |
| `4B` | `FSW` | `PARM 4Bxx` |
| `4C` | `FCN` | `PARM 4Cxx` |
| `4D` | `FDC` | `PARM 4Dxx` |
| `4E` | `FPN` | `PARM 4Exx` |
| `4F` | `MDM` | `PARM 4Fxx` |
| `50` | `MD1` | `PARM 50xx` |
| `51` | `MD2` | `PARM 51xx` |
| `52` | `MD3` | `PARM 52xx` |
| `53` | `MD4` | `PARM 53xx` |
| `54` | `MD5` | `PARM 54xx` |
| `55` | `MD6` | `PARM 55xx` |
| `56` | `MD7` | `PARM 56xx` |
| `57` | `MD8` | `PARM 57xx` |
| `58` | `MNM` | `PARM 58xx` |
| `59` | `MN1` | `PARM 59xx` |
| `5A` | `MN2` | `PARM 5Axx` |
| `5B` | `MN3` | `PARM 5Bxx` |
| `5C` | `MN4` | `PARM 5Cxx` |
| `5D` | `MN5` | `PARM 5Dxx` |
| `5E` | `MN6` | `PARM 5Exx` |
| `5F` | `MN7` | `PARM 5Fxx` |
| `60` | `MN8` | `PARM 60xx` |
| `61` | `HXM` | `PARM 61xx` |
| `62` | `HPR` | `PARM 62xx` |
| `63` | `HSP` | `PARM 63xx` |
| `64` | `HNO` | `PARM 64xx` |
| `65` | `HXT` | `PARM 65xx` |
| `66` | `HAT` | `PARM 66xx` |

## Build and install

The Android pipeline builds an Android arm64 APK from this R15 source over the pinned original
PocketTracker Android frontend. The PortMaster pipeline cross-compiles in Ubuntu 20.04 and
re-packs the R14 installer with the new binary. **The two binaries are not interchangeable.**

Android: install the debug APK after extracting the GitHub Actions artifact. The application
ID stays `com.oll.pockettracker3.r14.debug` so it can upgrade our current test app if signed
with the same debug certificate; a new GitHub runner key may require uninstalling first.
Back up user projects before uninstalling or replacing builds.

PortMaster: extract `pockettracker3_r15.zip` into the SD card `ports/` folder, preserving
`pockettracker3_r13/data/`. The existing launcher remains `PocketTracker 3 R13.sh` for
compatibility with PortMaster's current menu entry.

## Verification and remaining checks

R15 synthetic DSP checks cover buffer capture/hold/reverse and gate/tremolo resets,
indexed command registration and settings/editor syntax. The project is intentionally
built by CI for Android NDK and ARM64; real hardware/touch/audio performance remains to be
checked on devices before promoting this to a stable release.
