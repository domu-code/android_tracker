#!/bin/sh
# PocketTracker USB gadget lifecycle. It only owns usb_gadget/pockettracker.
# POCKETTRACKER_USB_SYSROOT redirects the kernel tree for the integration fixture.
set -eu
root=${POCKETTRACKER_USB_SYSROOT:-}
base="$root/sys/kernel/config/usb_gadget"
g="$base/pockettracker"
udcs="$root/sys/class/udc"
message() { printf 'message=%s\n' "$1"; }
fail() { printf 'active=0\nerror=%s\n' "$1"; exit 1; }
cleanup() {
    [ -d "$g" ] || return 0
    [ "$(cat "$g/strings/0x409/manufacturer" 2>/dev/null)" = PocketTracker ] || return 1
    printf '\n' > "$g/UDC" 2>/dev/null || true
    for n in midi.pt uac2.pt uac1.pt audio_source.pt; do rm -f "$g/configs/c.1/$n"; done
    rmdir "$g/configs/c.1/strings/0x409" "$g/configs/c.1" 2>/dev/null || true
    for n in uac2.pt uac1.pt audio_source.pt midi.pt; do rmdir "$g/functions/$n" 2>/dev/null || true; done
    rmdir "$g/strings/0x409" "$g" 2>/dev/null || true
}
case "${1:-status}" in
    stop)
        cleanup || fail 'USB DIRECTORY IS OWNED BY ANOTHER APP'
        printf 'active=0\nmode=HOST\n';message 'USB HOST MODE';exit 0 ;;
    status)
        if [ -d "$g" ] && [ -n "$(cat "$g/UDC" 2>/dev/null || true)" ]; then
            printf 'active=1\n'
            if [ -d "$g/functions/uac2.pt" ] || [ -d "$g/functions/uac1.pt" ]; then
                printf 'mode=DUPLEX_MIDI\naudio_name=UAC\nmidi_name=f_midi\n';message 'USB AUDIO IN-OUT + MIDI'
            elif [ -d "$g/functions/audio_source.pt" ]; then
                printf 'mode=SOURCE_MIDI\naudio_name=audio_source\nmidi_name=f_midi\n';message 'USB AUDIO OUT + MIDI'
            else printf 'mode=MIDI\nmidi_name=f_midi\n';message 'USB MIDI IN-OUT ONLY';fi
        else printf 'active=0\nmode=HOST\n';message 'USB HOST MODE';fi
        exit 0 ;;
    start|start-midi|probe) ;;
    *) fail 'UNKNOWN USB COMMAND' ;;
esac
[ "$(id -u)" = 0 ] || [ -n "$root" ] || fail 'USB DEVICE MODE NEEDS ROOT'
if [ ! -d "$base" ] && [ -z "$root" ]; then
    modprobe libcomposite 2>/dev/null || true
    mount -t configfs none /sys/kernel/config 2>/dev/null || true
fi
[ -d "$base" ] || fail 'KERNEL HAS NO USB CONFIGFS'
[ -d "$udcs" ] || fail 'NO USB DEVICE CONTROLLER'
udc=''
for controller in "$udcs"/*;do [ -e "$controller" ] || continue;udc=${controller##*/};break;done
[ -n "$udc" ] || fail 'NO USB DEVICE CONTROLLER'
for other in "$base"/*;do
    [ -d "$other" ] || continue
    [ "$other" = "$g" ] && continue
    bound=$(cat "$other/UDC" 2>/dev/null || true)
    [ -z "$bound" ] || fail 'USB BUSY - SET KNULLI USB MODE OFF'
done
if [ "$1" = probe ];then
    printf 'active=0\nmode=PROBE\n';message 'USB CONTROLLER READY - A ENABLES';exit 0
fi
if [ -d "$g" ] && [ "$(cat "$g/strings/0x409/manufacturer" 2>/dev/null || true)" != PocketTracker ];then
    fail 'USB DIRECTORY IS OWNED BY ANOTHER APP'
fi
if [ -d "$g" ] && [ -n "$(cat "$g/UDC" 2>/dev/null || true)" ];then "$0" status;exit 0;fi
mkdir -p "$g/strings/0x409" "$g/configs/c.1/strings/0x409"
printf 'PocketTracker\n' > "$g/strings/0x409/manufacturer"
trap 'code=$?;if [ "$code" != 0 ];then cleanup || true;message "USB SETUP FAILED - SEE LOG";fi' EXIT
printf '0x1d6b\n' > "$g/idVendor"
printf '0x0104\n' > "$g/idProduct"
printf '0x0200\n' > "$g/bcdUSB"
printf '0x0100\n' > "$g/bcdDevice"
printf '0xEF\n' > "$g/bDeviceClass"
printf '0x02\n' > "$g/bDeviceSubClass"
printf '0x01\n' > "$g/bDeviceProtocol"
serial=$(cat "$root/etc/machine-id" 2>/dev/null | cut -c1-16 || true)
printf '%s\n' "${serial:-PT3R7}" > "$g/strings/0x409/serialnumber"
printf 'PocketTracker R7\n' > "$g/strings/0x409/product"
printf 'PocketTracker Audio and MIDI\n' > "$g/configs/c.1/strings/0x409/configuration"
printf '2\n' > "$g/configs/c.1/MaxPower"
mkdir "$g/functions/midi.pt" 2>/dev/null || [ -d "$g/functions/midi.pt" ] || fail 'KERNEL HAS NO USB MIDI GADGET'
printf 'PTMidi\n' > "$g/functions/midi.pt/id"
printf '1\n' > "$g/functions/midi.pt/in_ports"
printf '1\n' > "$g/functions/midi.pt/out_ports"
ln -s "$g/functions/midi.pt" "$g/configs/c.1/midi.pt"
if [ "$1" != start-midi ];then
    audio=''
    for type in uac2 uac1;do
        if mkdir "$g/functions/$type.pt" 2>/dev/null;then
            fn="$g/functions/$type.pt"
            if [ -e "$fn/p_chmask" ] && [ -e "$fn/c_chmask" ];then
                printf '3\n' > "$fn/p_chmask";printf '3\n' > "$fn/c_chmask"
                printf '48000\n' > "$fn/p_srate";printf '48000\n' > "$fn/c_srate"
                printf '2\n' > "$fn/p_ssize";printf '2\n' > "$fn/c_ssize"
                audio=$type;ln -s "$fn" "$g/configs/c.1/$type.pt";break
            fi
            rmdir "$fn" 2>/dev/null || true
        fi
    done
    if [ -z "$audio" ] && mkdir "$g/functions/audio_source.pt" 2>/dev/null;then
        ln -s "$g/functions/audio_source.pt" "$g/configs/c.1/audio_source.pt"
    fi
fi
printf '%s\n' "$udc" > "$g/UDC"
trap - EXIT
"$0" status
